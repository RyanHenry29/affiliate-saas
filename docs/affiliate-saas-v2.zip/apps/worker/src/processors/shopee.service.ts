import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createHmac, createHash } from 'node:crypto';
import { NicheRouter } from '@affiliate-saas/shared-types';
import type {
  MarketplaceName,
  OfferNormalized,
} from '@affiliate-saas/shared-types';

const SHOPEE_OPEN_API_HOST = 'https://openapi.shopee.com';

interface ShopeeRawItem {
  item_id?: number;
  item_sku?: string;
  title?: string;
  price?: string | number;
  original_price?: string | number;
  rating_star?: string | number;
  image_url?: string;
  [key: string]: unknown;
}

@Injectable()
export class ShopeeService {
  private readonly logger = new Logger(ShopeeService.name);
  private readonly appId: string;
  private readonly appSecret: string;
  private readonly mockMode: boolean;

  constructor(private readonly config: ConfigService) {
    this.appId = this.config.get<string>('SHOPEE_APP_ID') ?? '';
    this.appSecret = this.config.get<string>('SHOPEE_APP_SECRET') ?? '';
    this.mockMode = this.config.get<string>('SHOPEE_MOCK_MINER') === 'true';
  }

  async mine(): Promise<OfferNormalized[]> {
    const raw = this.mockMode
      ? this.mockRawItems()
      : await this.fetchFromShopee();

    return raw
      .map((item) => this.normalize(item))
      .filter((o): o is OfferNormalized => o !== null)
      .filter((o) => o.discountPercent > 20 && o.rating > 4.5);
  }

  private async fetchFromShopee(): Promise<ShopeeRawItem[]> {
    if (!this.appId || !this.appSecret) {
      throw new Error('SHOPEE_APP_ID e SHOPEE_APP_SECRET obrigatórios');
    }
    const timestamp = Math.floor(Date.now() / 1000).toString();
    const sign = createHmac('sha256', this.appSecret)
      .update(`${this.appId}${timestamp}`)
      .digest('hex');

    const response = await fetch(
      `${SHOPEE_OPEN_API_HOST}/open/v1/affiliate/product/search`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Api-Key': this.appId,
          'X-Sign': sign,
          'X-Timestamp': timestamp,
        },
        body: JSON.stringify({ page: 0, size: 50, sortType: 1 }),
      },
    );
    if (!response.ok) {
      throw new Error(`Shopee API ${response.status}: ${await response.text()}`);
    }
    const json = (await response.json()) as {
      data?: { items?: ShopeeRawItem[] };
    };
    return json.data?.items ?? [];
  }

  private normalize(item: ShopeeRawItem): OfferNormalized | null {
    const title = item.title ?? '';
    const sku = item.item_sku ?? (item.item_id ? String(item.item_id) : '');
    if (!title || !sku) {
      return null;
    }
    const priceCents = this.toCents(item.price);
    const originalPriceCents = this.toCents(item.original_price);
    const discountPercent =
      originalPriceCents > 0
        ? Math.round(
            ((originalPriceCents - priceCents) / originalPriceCents) * 100,
          )
        : 0;
    const rating =
      typeof item.rating_star === 'number'
        ? item.rating_star
        : parseFloat(String(item.rating_star ?? '0')) || 0;

    return {
      marketplace: 'shopee',
      externalSku: sku,
      title,
      affiliateUrl: this.buildAffiliateUrl(sku),
      priceCents,
      originalPriceCents,
      discountPercent,
      rating,
      imageUrl: item.image_url,
      nicheTag: NicheRouter.classify(title),
      dedupeHash: this.dedupeHash('shopee', sku),
    };
  }

  private toCents(value: string | number | undefined): number {
    if (value === undefined || value === null) return 0;
    if (typeof value === 'number') return Math.round(value * 100);
    const parsed = parseFloat(value.replace(/[^\d.,-]/g, '').replace(',', '.'));
    return Number.isFinite(parsed) ? Math.round(parsed * 100) : 0;
  }

  private buildAffiliateUrl(sku: string): string {
    return `https://shopee.com.br/product/${encodeURIComponent(sku)}?af_siteid=0&utm_campaign=${this.appId}&utm_source=${this.appId}`;
  }

  private dedupeHash(marketplace: MarketplaceName, externalSku: string): string {
    return createHash('sha256')
      .update(`${marketplace}:${externalSku}`)
      .digest('hex');
  }

  private mockRawItems(): ShopeeRawItem[] {
    return [
      {
        item_id: 1001,
        item_sku: 'mock-fritadeira-air-fryer',
        title: 'Air Fryer 5L Digital Cozinha Fritadeira sem óleo',
        price: 219.9,
        original_price: 329.9,
        rating_star: 4.8,
        image_url: 'https://example.com/air-fryer.jpg',
      },
      {
        item_id: 1002,
        item_sku: 'mock-pneu-185-65-r15',
        title: 'Pneu 185/65 R15 Automotivo',
        price: 299,
        original_price: 419,
        rating_star: 4.7,
        image_url: 'https://example.com/pneu.jpg',
      },
      {
        item_id: 1003,
        item_sku: 'mock-racao-pet',
        title: 'Ração Premium para Cachorro 15kg',
        price: 189.9,
        original_price: 249.9,
        rating_star: 4.9,
        image_url: 'https://example.com/racao.jpg',
      },
      {
        item_id: 1004,
        item_sku: 'mock-fone-bluetooth',
        title: 'Fone de Ouvido Bluetooth TWS',
        price: 89.9,
        original_price: 99.9,
        rating_star: 4.4,
        image_url: 'https://example.com/fone.jpg',
      },
    ];
  }
}
