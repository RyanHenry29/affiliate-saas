import { Logger } from '@nestjs/common';
import {
  Processor,
  WorkerHost,
  OnWorkerEvent,
} from '@nestjs/bullmq';
import { Job } from 'bullmq';
import { PrismaService } from '../prisma.service';
import { EvolutionProvider } from '../evolution.provider';
import type { DispatchJobInput } from '@affiliate-saas/shared-types';

@Processor('dispatch')
export class DispatchProcessor extends WorkerHost {
  private readonly logger = new Logger(DispatchProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly provider: EvolutionProvider,
  ) {
    super();
  }

  /**
   * O coração da automação.
   * - Respeita o billing: tenant inadimplente não dispara (exceto Admin Master).
   * - Delay aleatório 30–90s por envio (anti-ban).
   * - Monta a legenda formatada com o link de afiliado.
   * - Atualiza o DispatchJob para SENT / FAILED / RATE_LIMITED.
   */
  async process(job: Job<DispatchJobInput>): Promise<void> {
    const { dispatchJobId, tenantId, offerId, groupId } = job.data;

    // 1) Bloqueio por billing (bypass para Admin Master).
    const tenant = await this.prisma.tenant.findUnique({
      where: { id: tenantId },
      include: { subscription: true },
    });
    if (!tenant) {
      this.logger.warn(`Tenant ${tenantId} não existe — abortando`);
      return;
    }
    if (!tenant.isAdminMaster) {
      const sub = tenant.subscription;
      const isDue = !sub || sub.status !== 'ACTIVE' || sub.currentPeriodEnd < new Date();
      if (isDue) {
        this.logger.warn(
          `Tenant ${tenantId} inadimplente (${sub?.status}) — disparo bloqueado`,
        );
        await this.prisma.dispatchJob.updateMany({
          where: { tenantId, status: 'PENDING' },
          data: { status: 'FAILED' },
        });
        return;
      }
    }

    // 2) Delay anti-ban: 30–90s por envio.
    const antiBanDelay = 30_000 + Math.floor(Math.random() * 60_000);
    this.logger.debug(
      `Anti-ban: aguardando ${Math.round(antiBanDelay / 1000)}s para job ${job.id}`,
    );
    await this.delay(antiBanDelay);

    // 3) Carrega oferta + grupo + instância conectada.
    const offer = await this.prisma.offer.findUnique({ where: { id: offerId } });
    if (!offer) {
      this.logger.warn(`Oferta ${offerId} não encontrada — marcando FAILED`);
      await this.prisma.dispatchJob.update({
        where: { id: dispatchJobId },
        data: { status: 'FAILED', attempts: { increment: 1 } },
      });
      return;
    }

    const group = await this.prisma.group.findFirst({
      where: { id: groupId, tenantId },
    });
    if (!group) {
      this.logger.warn(`Grupo ${groupId} não encontrado — marcando FAILED`);
      await this.prisma.dispatchJob.update({
        where: { id: dispatchJobId },
        data: { status: 'FAILED', attempts: { increment: 1 } },
      });
      return;
    }

    const instance = await this.prisma.messagingInstance.findFirst({
      where: { tenantId, provider: 'whatsapp', status: 'CONNECTED' },
    });
    if (!instance) {
      this.logger.warn(`Tenant ${tenantId} sem instância conectada`);
      // Sem instância: não é erro de envio — deixa o job aguardar novo ciclo
      // em vez de marcar FAILED. Aguardamos re-processamento com backoff.
      throw new Error('SEM_INSTANCIA_CONECTADA');
    }

    // 4) Formata a legenda com o link de afiliado.
    const text = this.buildMessage(offer.title, offer.affiliateUrl, offer.priceCents);

    // 5) Envia via Evolution API.
    const result = await this.provider.sendToGroup({
      tenantId,
      instanceExternalId: instance.externalId,
      groupExternalId: group.externalId,
      text,
      mediaUrl: offer.imageUrl ?? undefined,
    });

    // 6) Atualiza o DispatchJob.
    await this.prisma.dispatchJob.update({
      where: { id: dispatchJobId },
      data: {
        status: result.status,
        attempts: { increment: 1 },
        sentAt: result.status === 'SENT' ? new Date() : null,
      },
    });

    if (result.status === 'RATE_LIMITED') {
      throw new Error('RATE_LIMITED');
    }
    if (result.status === 'FAILED') {
      throw new Error(result.errorReason ?? 'ENVIO_FALHOU');
    }
  }

  @OnWorkerEvent('failed')
  onFailed(job: Job<DispatchJobInput> | undefined, err: Error): void {
    this.logger.error(`Job ${job?.id ?? '?'} falhou: ${err.message}`);
  }

  private buildMessage(title: string, affiliateUrl: string, priceCents: number): string {
    const price = (priceCents / 100).toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
    return [
      `🔥 *${title}*`,
      ``,
      `💰 Aproveite por apenas *${price}*!`,
      ``,
      `🛒 Clique no link e garanta já:`,
      affiliateUrl,
    ].join('\n');
  }

  private delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}
