import { Logger } from '@nestjs/common';
import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import { PrismaService } from '../prisma.service';

@Processor('billing-sync')
export class BillingSyncProcessor extends WorkerHost {
  private readonly logger = new Logger(BillingSyncProcessor.name);

  constructor(private readonly prisma: PrismaService) {
    super();
  }

  /**
   * Job de verificação (diário / cron no host):
   * tenants com assinatura expirada viram PAST_DUE — e o DispatchProcessor
   * bloqueia automaticamente os disparos desses tenants.
   */
  async process(job: Job<{ tenantId?: string }>): Promise<void> {
    if (job.data.tenantId) {
      await this.syncTenant(job.data.tenantId);
      return;
    }

    const expired = await this.prisma.subscription.findMany({
      where: {
        status: 'ACTIVE',
        currentPeriodEnd: { lt: new Date() },
      },
      include: { tenant: true },
    });

    let blocked = 0;
    for (const sub of expired) {
      if (sub.tenant.isAdminMaster) continue;
      await this.prisma.subscription.update({
        where: { id: sub.id },
        data: { status: 'PAST_DUE' },
      });
      await this.prisma.dispatchJob.updateMany({
        where: { tenantId: sub.tenantId, status: 'PENDING' },
        data: { status: 'FAILED' },
      });
      blocked += 1;
      this.logger.warn(
        `Tenant ${sub.tenantId} bloqueado por inadimplência (vencido ${sub.currentPeriodEnd.toISOString()})`,
      );
    }
    this.logger.log(`Billing sync: ${blocked} tenants bloqueados`);
  }

  private async syncTenant(tenantId: string): Promise<void> {
    const sub = await this.prisma.subscription.findUnique({
      where: { tenantId },
      include: { tenant: true },
    });
    if (!sub || sub.tenant.isAdminMaster) return;
    if (sub.status === 'ACTIVE' && sub.currentPeriodEnd < new Date()) {
      await this.prisma.subscription.update({
        where: { id: sub.id },
        data: { status: 'PAST_DUE' },
      });
      await this.prisma.dispatchJob.updateMany({
        where: { tenantId, status: 'PENDING' },
        data: { status: 'FAILED' },
      });
      this.logger.warn(`Tenant ${tenantId} bloqueado por inadimplência`);
    }
  }
}
