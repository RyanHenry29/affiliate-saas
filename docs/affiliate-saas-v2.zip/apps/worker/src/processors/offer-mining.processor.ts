import { Logger } from '@nestjs/common';
import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import { PrismaService } from '../prisma.service';
import { ShopeeService } from './shopee.service';

@Processor('offer-mining')
export class OfferMiningProcessor extends WorkerHost {
  private readonly logger = new Logger(OfferMiningProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly shopee: ShopeeService,
  ) {
    super();
  }

  async process(job: Job<{ marketplace: string }>): Promise<void> {
    const { marketplace } = job.data;

    if (marketplace === 'shopee') {
      const mined = await this.shopee.mine();

      const created = await this.prisma.offer.createMany({
        data: mined.map((o) => ({
          marketplace: o.marketplace,
          externalSku: o.externalSku,
          title: o.title,
          affiliateUrl: o.affiliateUrl,
          imageUrl: o.imageUrl,
          priceCents: o.priceCents,
          originalPriceCents: o.originalPriceCents,
          discountPercent: o.discountPercent,
          rating: o.rating,
          nicheTag: o.nicheTag,
          dedupeHash: o.dedupeHash,
        })),
        skipDuplicates: true,
      });

      this.logger.log(
        `Mineração shopee: ${created.count} novas de ${mined.length}`,
      );
      return;
    }

    this.logger.warn(`Marketplace ${marketplace} ainda não suportado no worker`);
  }
}
