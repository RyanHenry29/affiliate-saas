import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { BullModule } from '@nestjs/bullmq';
import { resolve } from 'node:path';
import { PrismaService } from './prisma.service';
import { EvolutionProvider } from './evolution.provider';
import { DispatchProcessor } from './processors/dispatch.processor';
import { OfferMiningProcessor } from './processors/offer-mining.processor';
import { BillingSyncProcessor } from './processors/billing-sync.processor';
import { ShopeeService } from './processors/shopee.service';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: [resolve(__dirname, '../../../.env'), '.env'],
    }),
    BullModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        connection: { url: config.getOrThrow<string>('REDIS_URL') },
      }),
    }),
    BullModule.registerQueue(
      { name: 'dispatch' },
      { name: 'offer-mining' },
      { name: 'billing-sync' },
    ),
  ],
  providers: [
    PrismaService,
    EvolutionProvider,
    ShopeeService,
    DispatchProcessor,
    OfferMiningProcessor,
    BillingSyncProcessor,
  ],
})
export class WorkerModule {}
