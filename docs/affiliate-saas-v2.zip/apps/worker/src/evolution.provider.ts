import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createHmac } from 'node:crypto';
import type { DispatchResult, MessagingProvider } from './messaging-provider.interface';

@Injectable()
export class EvolutionProvider implements MessagingProvider {
  readonly providerName = 'whatsapp-unofficial' as const;

  private readonly logger = new Logger(EvolutionProvider.name);
  private readonly baseUrl: string;
  private readonly apiKey: string;

  constructor(private readonly config: ConfigService) {
    this.baseUrl =
      this.config.get<string>('EVOLUTION_API_URL') ?? 'http://localhost:8080';
    this.apiKey = this.config.get<string>('EVOLUTION_API_KEY') ?? '';
  }

  async sendToGroup(params: {
    tenantId: string;
    instanceExternalId: string;
    groupExternalId: string;
    text: string;
    mediaUrl?: string;
  }): Promise<DispatchResult> {
    const { instanceExternalId, groupExternalId, text, mediaUrl } = params;
    try {
      const endpoint = mediaUrl ? 'sendMedia' : 'sendText';
      const response = await fetch(
        `${this.baseUrl}/message/${endpoint}/${instanceExternalId}`,
        {
          method: 'POST',
          headers: {
            apikey: this.apiKey,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(
            mediaUrl
              ? { number: groupExternalId, mediatype: 'image', media: mediaUrl, caption: text }
              : { number: groupExternalId, text },
          ),
        },
      );

      if (!response.ok) {
        const body = await response.text();
        if (/429|rate|limit|too many/i.test(body)) {
          return { externalMessageId: null, status: 'RATE_LIMITED', errorReason: body };
        }
        return { externalMessageId: null, status: 'FAILED', errorReason: body };
      }
      const data = (await response.json()) as { key?: { id?: string } };
      return {
        externalMessageId: data.key?.id ?? null,
        status: 'SENT',
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      this.logger.error(`EvolutionProvider falha: ${message}`);
      return { externalMessageId: null, status: 'FAILED', errorReason: message };
    }
  }

  async getInstanceStatus(
    instanceExternalId: string,
  ): Promise<'CONNECTED' | 'DISCONNECTED' | 'ERROR'> {
    try {
      const response = await fetch(
        `${this.baseUrl}/instance/connectionState/${instanceExternalId}`,
        { headers: { apikey: this.apiKey } },
      );
      if (!response.ok) {
        return 'ERROR';
      }
      const data = (await response.json()) as { status?: string };
      return data.status === 'open' ? 'CONNECTED' : 'DISCONNECTED';
    } catch (error) {
      this.logger.error(`getInstanceStatus falha: ${String(error)}`);
      return 'ERROR';
    }
  }
}
