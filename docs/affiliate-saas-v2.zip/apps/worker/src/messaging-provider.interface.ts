export interface DispatchResult {
  externalMessageId: string | null;
  status: 'SENT' | 'FAILED' | 'RATE_LIMITED';
  errorReason?: string;
}

export interface MessagingProvider {
  readonly providerName: 'whatsapp-unofficial' | 'whatsapp-cloud' | 'telegram';
  sendToGroup(params: {
    tenantId: string;
    instanceExternalId: string;
    groupExternalId: string;
    text: string;
    mediaUrl?: string;
  }): Promise<DispatchResult>;
  getInstanceStatus(
    instanceExternalId: string,
  ): Promise<'CONNECTED' | 'DISCONNECTED' | 'ERROR'>;
}
