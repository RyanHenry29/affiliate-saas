export type NicheTag =
  | "DONA_DE_CASA"
  | "AUTOMOTIVO"
  | "ELETRONICOS"
  | "MODA"
  | "BELEZA"
  | "ESPORTES"
  | "INFANTIL"
  | "PETS"
  | "GERAL";

export type MarketplaceName = "shopee" | "amazon" | "aliexpress" | "awin";

export type DispatchStatus = "PENDING" | "SENT" | "FAILED" | "RATE_LIMITED";

export type InstanceStatus =
  | "CONNECTED"
  | "CONNECTING"
  | "DISCONNECTED"
  | "FAILED";

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  accessTokenExpiresIn: number;
}

export interface AuthUserResponse {
  id: string;
  email: string;
  tenantId: string;
  role: string;
  isAdminMaster: boolean;
  tenantName: string;
}

export interface LoginResponse extends AuthTokens {
  user: AuthUserResponse;
}

export interface Group {
  id: string;
  tenantId: string;
  externalId: string;
  name: string;
  nicheTags: NicheTag[];
  active: boolean;
}

export interface Offer {
  id: string;
  marketplace: MarketplaceName;
  externalSku: string;
  title: string;
  affiliateUrl: string;
  imageUrl: string | null;
  priceCents: number;
  originalPriceCents: number;
  discountPercent: number;
  rating: number;
  nicheTag: NicheTag;
  scrapedAt: string;
  dedupeHash: string;
}

export interface MessagingInstance {
  id: string;
  tenantId: string;
  provider: string;
  externalId: string;
  status: InstanceStatus;
  createdAt: string;
}

export interface Subscription {
  id: string;
  tenantId: string;
  plan: "STARTER" | "PRO" | "AGENCY";
  status: "ACTIVE" | "PAST_DUE" | "CANCELED" | "TRIALING";
  currentPeriodEnd: string;
}

export interface ApiErrorBody {
  message?: string | string[];
  error?: string;
  statusCode?: number;
}

export const NICHE_LABELS: Record<NicheTag, string> = {
  DONA_DE_CASA: "Dona de casa",
  AUTOMOTIVO: "Automotivo",
  ELETRONICOS: "Eletrônicos",
  MODA: "Moda",
  BELEZA: "Beleza",
  ESPORTES: "Esportes",
  INFANTIL: "Infantil",
  PETS: "Pets",
  GERAL: "Geral",
};

export const NICHE_TAGS: NicheTag[] = Object.keys(
  NICHE_LABELS,
) as NicheTag[];

export const MARKETPLACE_LABELS: Record<MarketplaceName, string> = {
  shopee: "Shopee",
  amazon: "Amazon",
  aliexpress: "AliExpress",
  awin: "Awin",
};

export const PLAN_LABELS: Record<string, string> = {
  STARTER: "Iniciante",
  PRO: "Profissional",
  AGENCY: "Agency",
};
