"use client";

import type {
  ApiErrorBody,
  AuthTokens,
  AuthUserResponse,
  Group,
  LoginResponse,
  MessagingInstance,
  NicheTag,
  Offer,
} from "./types";

const API_URL =
  process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:3000/api";

export const TOKENS_KEY = "affiliate_saas_tokens";
export const USER_KEY = "affiliate_saas_user";

export interface StoredTokens {
  accessToken: string;
  refreshToken: string;
}

export function getTokens(): StoredTokens | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(TOKENS_KEY);
    return raw ? (JSON.parse(raw) as StoredTokens) : null;
  } catch {
    return null;
  }
}

export function setTokens(tokens: AuthTokens) {
  window.localStorage.setItem(
    TOKENS_KEY,
    JSON.stringify({
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
    }),
  );
}

export function clearTokens() {
  window.localStorage.removeItem(TOKENS_KEY);
  window.localStorage.removeItem(USER_KEY);
}

export function getStoredUser(): AuthUserResponse | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(USER_KEY);
    return raw ? (JSON.parse(raw) as AuthUserResponse) : null;
  } catch {
    return null;
  }
}

function apiError(data: ApiErrorBody | undefined, status: number): Error {
  const msg = Array.isArray(data?.message)
    ? data!.message!.join(", ")
    : data?.message;
  const err = new Error(msg ?? `Erro na requisição (${status})`);
  (err as Error & { status?: number }).status = status;
  return err;
}

let refreshPromise: Promise<AuthTokens> | null = null;

async function refreshAccessToken(): Promise<AuthTokens> {
  const tokens = getTokens();
  if (!tokens?.refreshToken) throw new Error("Sem sessão");
  if (!refreshPromise) {
    refreshPromise = fetch(`${API_URL}/auth/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refreshToken: tokens.refreshToken }),
    }).then(async (res) => {
      if (!res.ok) throw new Error("Sessão expirada");
      const data = (await res.json()) as AuthTokens;
      setTokens(data);
      return data;
    });
  }
  try {
    return await refreshPromise;
  } finally {
    refreshPromise = null;
  }
}

export async function apiRequest<T>(
  path: string,
  options: RequestInit = {},
): Promise<T> {
  const tokens = getTokens();
  const headers = new Headers(options.headers);
  headers.set("Content-Type", "application/json");
  if (tokens?.accessToken) {
    headers.set("Authorization", `Bearer ${tokens.accessToken}`);
  }

  let res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers,
  });

  if (res.status === 401 && tokens?.refreshToken) {
    try {
      const fresh = await refreshAccessToken();
      headers.set("Authorization", `Bearer ${fresh.accessToken}`);
      res = await fetch(`${API_URL}${path}`, {
        ...options,
        headers,
      });
    } catch {
      clearTokens();
      throw new Error("Sessão expirada. Faça login novamente.");
    }
  }

  if (res.status === 204) return undefined as T;

  const body = await res.json().catch(() => null);
  if (!res.ok) throw apiError(body, res.status);
  return body as T;
}

export const api = {
  login: (email: string, password: string) =>
    apiRequest<LoginResponse>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    }),
  register: (email: string, password: string, tenantName: string) =>
    apiRequest<LoginResponse>("/auth/register", {
      method: "POST",
      body: JSON.stringify({ email, password, tenantName }),
    }),
  logout: (refreshToken: string) =>
    apiRequest<void>("/auth/logout", {
      method: "POST",
      body: JSON.stringify({ refreshToken }),
    }),
  me: () => apiRequest<AuthUserResponse>("/auth/me"),
  listGroups: () => apiRequest<Group[]>("/groups"),
  createGroup: (data: {
    externalId: string;
    name: string;
    nicheTags: NicheTag[];
    active?: boolean;
  }) =>
    apiRequest<Group>("/groups", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  updateGroup: (id: string, data: Partial<Group>) =>
    apiRequest<Group>(`/groups/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),
  deleteGroup: (id: string) =>
    apiRequest<{ id: string }>(`/groups/${id}`, { method: "DELETE" }),
  listOffers: (nicheTag?: NicheTag) =>
    apiRequest<Offer[]>(
      `/offers${nicheTag ? `?nicheTag=${encodeURIComponent(nicheTag)}` : ""}`,
    ),
  mineShopee: () =>
    apiRequest<{
      inserted: number;
      duplicates: number;
      dispatched: number;
    }>("/offers/mine/shopee", { method: "POST" }),
  listInstances: () =>
    apiRequest<MessagingInstance[]>("/messaging/instances"),
  createInstance: (provider: string, externalId: string) =>
    apiRequest<MessagingInstance>("/messaging/instances", {
      method: "POST",
      body: JSON.stringify({ provider, externalId }),
    }),
  refreshInstanceStatuses: () =>
    apiRequest<{ id: string; status: string }[]>(
      "/messaging/instances/refresh",
      { method: "POST" },
    ),
};
