"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { useRouter } from "next/navigation";
import {
  api,
  clearTokens,
  getStoredUser,
  getTokens,
  setTokens,
} from "./api";
import type { AuthUserResponse } from "./types";

interface AuthContextValue {
  user: AuthUserResponse | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (
    email: string,
    password: string,
    tenantName: string,
  ) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const [user, setUser] = useState<AuthUserResponse | null>(() =>
    getStoredUser(),
  );
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const tokens = getTokens();
    if (!tokens?.accessToken) return;
    api
      .me()
      .then((me) => {
        setUser(me);
        window.localStorage.setItem(
          "affiliate_saas_user",
          JSON.stringify(me),
        );
      })
      .catch(() => {
        clearTokens();
        setUser(null);
      });
  }, []);

  const login = useCallback(
    async (email: string, password: string) => {
      setLoading(true);
      try {
        const res = await api.login(email, password);
        setTokens(res);
        const stored = {
          id: res.user.id,
          email: res.user.email,
          tenantId: res.user.tenantId,
          role: res.user.role,
          isAdminMaster: res.user.isAdminMaster,
          tenantName: res.user.tenantName,
        };
        setUser(stored);
        window.localStorage.setItem(
          "affiliate_saas_user",
          JSON.stringify(stored),
        );
        router.push("/dashboard");
      } finally {
        setLoading(false);
      }
    },
    [router],
  );

  const register = useCallback(
    async (email: string, password: string, tenantName: string) => {
      setLoading(true);
      try {
        const res = await api.register(email, password, tenantName);
        setTokens(res);
        const stored = {
          id: res.user.id,
          email: res.user.email,
          tenantId: res.user.tenantId,
          role: res.user.role,
          isAdminMaster: res.user.isAdminMaster,
          tenantName: res.user.tenantName,
        };
        setUser(stored);
        window.localStorage.setItem(
          "affiliate_saas_user",
          JSON.stringify(stored),
        );
        router.push("/dashboard");
      } finally {
        setLoading(false);
      }
    },
    [router],
  );

  const logout = useCallback(async () => {
    const tokens = getTokens();
    if (tokens?.refreshToken) {
      await api.logout(tokens.refreshToken).catch(() => undefined);
    }
    clearTokens();
    setUser(null);
    router.push("/login");
  }, [router]);

  const value = useMemo(
    () => ({ user, loading, login, register, logout }),
    [user, loading, login, register, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth deve ser usado dentro de AuthProvider");
  return ctx;
}
