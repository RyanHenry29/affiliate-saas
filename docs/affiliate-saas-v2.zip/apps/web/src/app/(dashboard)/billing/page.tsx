"use client";

import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { SubscriptionBadge } from "@/components/status-badge";
import { formatBRL } from "@/lib/utils";
import { PLAN_LABELS } from "@/lib/types";
import {
  MOCK_INVOICES,
  PLANS,
  getMockSubscription,
} from "@/lib/subscription";

export default function BillingPage() {
  const subscription = getMockSubscription();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-lg font-semibold">Assinatura</h1>
        <p className="text-sm text-muted-foreground">
          Gerencie seu plano e histórico de cobrança
        </p>
      </div>

      <Card>
        <CardContent className="flex flex-wrap items-center justify-between gap-3 p-5">
          <div>
            <p className="text-sm text-muted-foreground">Plano atual</p>
            <div className="mt-0.5 flex items-center gap-2">
              <p className="text-lg font-semibold">
                {PLAN_LABELS[subscription.plan]}
              </p>
              <SubscriptionBadge status={subscription.status} />
            </div>
          </div>
          <div className="text-sm text-muted-foreground">
            Próxima cobrança:{" "}
            <span className="font-medium text-foreground">
              {new Date(subscription.currentPeriodEnd).toLocaleDateString(
                "pt-BR",
              )}
            </span>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-3 md:grid-cols-3">
        {PLANS.map((plan) => (
          <Card
            key={plan.id}
            className={
              plan.highlight ? "border-primary/60 bg-primary/5" : undefined
            }
          >
            <CardContent className="flex flex-col gap-3 p-5">
              <div>
                <p className="font-semibold">{plan.name}</p>
                <p className="mt-1 font-mono text-xl">{plan.price}</p>
              </div>
              <ul className="space-y-1.5 text-sm text-muted-foreground">
                {[plan.instances, plan.groups, plan.dispatchLimit].map((f) => (
                  <li key={f} className="flex items-center gap-2">
                    <Check className="h-4 w-4 shrink-0 text-success" />
                    {f}
                  </li>
                ))}
              </ul>
              <Button
                variant={plan.highlight ? "default" : "outline"}
                disabled={plan.id === subscription.plan}
                className="mt-auto"
              >
                {plan.id === subscription.plan ? "Plano atual" : "Escolher"}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardContent className="p-5">
          <h3 className="mb-3 text-base font-semibold">Histórico de faturas</h3>
          <div className="divide-y divide-border">
            {MOCK_INVOICES.map((invoice) => (
              <div
                key={invoice.id}
                className="flex items-center justify-between gap-3 py-2.5"
              >
                <div>
                  <p className="text-sm font-medium">{invoice.description}</p>
                  <p className="font-mono text-xs text-muted-foreground">
                    {invoice.id} ·{" "}
                    {new Date(invoice.date).toLocaleDateString("pt-BR")}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-mono text-sm">
                    {formatBRL(invoice.amountCents)}
                  </p>
                  <p className="text-xs text-success">Pago</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
