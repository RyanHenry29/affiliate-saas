"use client";

import { useEffect, useState, type FormEvent } from "react";
import {
  Loader2,
  Pencil,
  Plus,
  Trash2,
  Users as UsersIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { api } from "@/lib/api";
import { cn } from "@/lib/utils";
import {
  NICHE_LABELS,
  NICHE_TAGS,
  type Group,
  type NicheTag,
} from "@/lib/types";

interface GroupForm {
  id: string | null;
  name: string;
  externalId: string;
  nicheTags: NicheTag[];
  active: boolean;
}

const EMPTY_FORM: GroupForm = {
  id: null,
  name: "",
  externalId: "",
  nicheTags: ["GERAL"],
  active: true,
};

export default function GroupsPage() {
  const [groups, setGroups] = useState<Group[] | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Group | null>(null);
  const [form, setForm] = useState<GroupForm>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    void api.listGroups().then(setGroups).catch(() => setGroups([]));
  }, []);

  function openNew() {
    setForm(EMPTY_FORM);
    setError(null);
    setDialogOpen(true);
  }

  function openEdit(group: Group) {
    setForm({
      id: group.id,
      name: group.name,
      externalId: group.externalId,
      nicheTags: group.nicheTags,
      active: group.active,
    });
    setError(null);
    setDialogOpen(true);
  }

  function toggleNiche(tag: NicheTag) {
    setForm((f) => ({
      ...f,
      nicheTags: f.nicheTags.includes(tag)
        ? f.nicheTags.filter((t) => t !== tag)
        : [...f.nicheTags, tag],
    }));
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (!form.name.trim() || !form.externalId.trim()) {
      setError("Nome e ID externo são obrigatórios");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        externalId: form.externalId.trim(),
        nicheTags: form.nicheTags,
        active: form.active,
      };
      if (form.id) {
        await api.updateGroup(form.id, payload);
      } else {
        await api.createGroup(payload);
      }
      setGroups(await api.listGroups());
      setDialogOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível salvar");
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    try {
      await api.deleteGroup(deleteTarget.id);
      setGroups((g) => (g ?? []).filter((x) => x.id !== deleteTarget.id));
    } catch {
      // mantém lista
    } finally {
      setDeleteTarget(null);
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-semibold">Grupos</h1>
          <p className="text-sm text-muted-foreground">
            Grupos vinculados aos nichos para recebimento de ofertas
          </p>
        </div>
        <Button onClick={openNew}>
          <Plus className="h-4 w-4" aria-hidden />
          Novo grupo
        </Button>
      </div>

      <Card>
        <CardContent className="p-4">
          {groups === null ? (
            <div className="space-y-2">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-12 rounded-md" />
              ))}
            </div>
          ) : groups.length === 0 ? (
            <div className="flex flex-col items-center gap-2 py-10 text-center">
              <UsersIcon className="h-8 w-8 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                Nenhum grupo cadastrado ainda.
              </p>
              <Button variant="outline" size="sm" onClick={openNew}>
                Criar o primeiro grupo
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>ID externo</TableHead>
                  <TableHead>Nichos</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {groups.map((group) => (
                  <TableRow key={group.id}>
                    <TableCell className="font-medium">{group.name}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {group.externalId}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {group.nicheTags.map((tag) => (
                          <Badge key={tag} variant="outline">
                            {NICHE_LABELS[tag]}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={group.active}
                        onCheckedChange={async (active) => {
                          await api
                            .updateGroup(group.id, { active })
                            .catch(() => undefined);
                          setGroups((g) =>
                            (g ?? []).map((x) =>
                              x.id === group.id ? { ...x, active } : x,
                            ),
                          );
                        }}
                        aria-label={`Ativar grupo ${group.name}`}
                      />
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openEdit(group)}
                          aria-label={`Editar ${group.name}`}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setDeleteTarget(group)}
                          aria-label={`Excluir ${group.name}`}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {form.id ? "Editar grupo" : "Novo grupo"}
            </DialogTitle>
            <DialogDescription>
              O ID externo é a identificação do grupo no provider
              (Evolution API ou Telegram).
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={onSubmit} className="space-y-4">
            {error && (
              <div className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {error}
              </div>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="name">Nome</Label>
              <Input
                id="name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Achadinhos da Cozinha"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="externalId">ID externo no provider</Label>
              <Input
                id="externalId"
                value={form.externalId}
                onChange={(e) =>
                  setForm({ ...form, externalId: e.target.value })
                }
                placeholder="12036304xxxxxx@c.us"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Nichos que este grupo recebe</Label>
              <div className="flex flex-wrap gap-1.5">
                {NICHE_TAGS.map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => toggleNiche(tag)}
                    className={cn(
                      "rounded-md border px-2.5 py-1 text-xs font-medium transition-colors",
                      form.nicheTags.includes(tag)
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border text-muted-foreground hover:bg-accent",
                    )}
                  >
                    {NICHE_LABELS[tag]}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="active">Grupo ativo</Label>
              <Switch
                id="active"
                checked={form.active}
                onCheckedChange={(active) =>
                  setForm({ ...form, active })
                }
              />
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancelar
              </Button>
              <Button type="submit" disabled={saving}>
                {saving && <Loader2 className="animate-spin" aria-hidden />}
                Salvar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Excluir grupo?</DialogTitle>
            <DialogDescription>
              {deleteTarget?.name} deixará de receber ofertas. Essa ação não
              pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteTarget(null)}
            >
              Cancelar
            </Button>
            <Button variant="destructive" onClick={() => void confirmDelete()}>
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
