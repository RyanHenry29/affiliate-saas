"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ImageOff, Loader2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { api } from "@/lib/api";
import { cn, formatBRL, timeAgo } from "@/lib/utils";
import {
  MARKETPLACE_LABELS,
  NICHE_LABELS,
  NICHE_TAGS,
  type MarketplaceName,
  type NicheTag,
  type Offer,
} from "@/lib/types";
import { useAuth } from "@/lib/auth";

const MARKETPLACES: (MarketplaceName | "all")[] = [
  "all",
  "shopee",
  "amazon",
  "aliexpress",
  "awin",
];

const NICHE_BADGE: Record<NicheTag, string> = {
  DONA_DE_CASA: "border-primary/40 bg-primary/10 text-primary",
  AUTOMOTIVO: "border-success/40 bg-success/10 text-success",
  ELETRONICOS: "border-warning/40 bg-warning/10 text-warning",
  MODA: "border-primary/40 bg-primary/10 text-primary",
  BELEZA: "border-warning/40 bg-warning/10 text-warning",
  ESPORTES: "border-success/40 bg-success/10 text-success",
  INFANTIL: "border-primary/40 bg-primary/10 text-primary",
  PETS: "border-success/40 bg-success/10 text-success",
  GERAL: "border-border bg-muted text-muted-foreground",
};

export default function OffersPage() {
  const { user } = useAuth();
  const [offers, setOffers] = useState<Offer[] | null>(null);
  const [marketplace, setMarketplace] = useState<MarketplaceName | "all">(
    "all",
  );
  const [niche, setNiche] = useState<NicheTag | "all">("all");
  const [search, setSearch] = useState("");
  const [mining, setMining] = useState(false);
  const [mineResult, setMineResult] = useState<string | null>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    void api.listOffers().then(setOffers).catch(() => setOffers([]));
  }, []);

  const setSearchDebounced = useCallback((value: string) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => setSearch(value), 300);
  }, []);

  useEffect(
    () => () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    },
    [],
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return (offers ?? []).filter((o) => {
      if (marketplace !== "all" && o.marketplace !== marketplace) return false;
      if (niche !== "all" && o.nicheTag !== niche) return false;
      if (q && !o.title.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [offers, marketplace, niche, search]);

  async function mineShopee() {
    setMining(true);
    setMineResult(null);
    try {
      const res = await api.mineShopee();
      setMineResult(
        `${res.inserted} nova(s), ${res.duplicates} duplicada(s), ${res.dispatched} disparo(s) enfileirado(s)`,
      );
      setOffers(await api.listOffers());
    } catch (err) {
      setMineResult(
        err instanceof Error ? err.message : "Falha ao minerar",
      );
    } finally {
      setMining(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-semibold">Ofertas mineradas</h1>
          <p className="text-sm text-muted-foreground">
            {offers === null ? "Carregando..." : `${filtered.length} exibidas`}
          </p>
        </div>
        {user?.isAdminMaster && (
          <Button onClick={() => void mineShopee()} disabled={mining}>
            {mining ? (
              <Loader2 className="animate-spin" aria-hidden />
            ) : (
              <RefreshCw className="h-4 w-4" aria-hidden />
            )}
            Minerar Shopee agora
          </Button>
        )}
      </div>

      {mineResult && (
        <div className="rounded-md border border-border bg-card px-3 py-2 text-sm">
          {mineResult}
        </div>
      )}

      <Card>
        <CardContent className="space-y-4 p-4">
          <div className="flex flex-wrap gap-2">
            <Input
              placeholder="Buscar por título..."
              className="max-w-xs"
              defaultValue={search}
              onChange={(e) => setSearchDebounced(e.target.value)}
              aria-label="Buscar ofertas"
            />
            <Select
              value={marketplace}
              onValueChange={(v) =>
                setMarketplace(v as MarketplaceName | "all")
              }
            >
              <SelectTrigger className="w-40" aria-label="Marketplace">
                <SelectValue placeholder="Marketplace" />
              </SelectTrigger>
              <SelectContent>
                {MARKETPLACES.map((m) => (
                  <SelectItem key={m} value={m}>
                    {m === "all" ? "Todos" : MARKETPLACE_LABELS[m]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={niche}
              onValueChange={(v) => setNiche(v as NicheTag | "all")}
            >
              <SelectTrigger className="w-40" aria-label="Nicho">
                <SelectValue placeholder="Nicho" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                {NICHE_TAGS.map((n) => (
                  <SelectItem key={n} value={n}>
                    {NICHE_LABELS[n]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {offers === null ? (
            <div className="space-y-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-12 rounded-md" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">
              Nenhuma oferta encontrada com os filtros atuais.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12" />
                  <TableHead>Título</TableHead>
                  <TableHead>Marketplace</TableHead>
                  <TableHead>Nicho</TableHead>
                  <TableHead className="text-right">Preço</TableHead>
                  <TableHead className="text-right">Desconto</TableHead>
                  <TableHead className="text-right">Coletada</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((offer) => (
                  <TableRow key={offer.id}>
                    <TableCell>
                      <div className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-md border bg-muted">
                        {offer.imageUrl ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={offer.imageUrl}
                            alt=""
                            loading="lazy"
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <ImageOff className="h-4 w-4 text-muted-foreground" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="max-w-[280px] truncate">
                      <a
                        href={offer.affiliateUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="hover:text-primary hover:underline"
                      >
                        {offer.title}
                      </a>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {MARKETPLACE_LABELS[offer.marketplace]}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={NICHE_BADGE[offer.nicheTag]}
                      >
                        {NICHE_LABELS[offer.nicheTag]}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      {formatBRL(offer.priceCents)}
                      <span
                        className={cn(
                          "ml-2 text-xs",
                          offer.discountPercent >= 20
                            ? "text-success"
                            : "text-muted-foreground",
                        )}
                      >
                        {offer.discountPercent.toFixed(0)}%
                      </span>
                    </TableCell>
                    <TableCell className="text-right text-xs text-muted-foreground">
                      {formatBRL(offer.originalPriceCents)}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-right text-xs text-muted-foreground">
                      {timeAgo(offer.scrapedAt)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
