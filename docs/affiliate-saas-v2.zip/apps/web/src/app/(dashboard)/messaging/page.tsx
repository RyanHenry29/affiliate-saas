"use client";

import { useEffect, useState, type FormEvent } from "react";
import { motion } from "framer-motion";
import {
  Loader2,
  MessageCircle,
  Plus,
  QrCode,
  RefreshCw,
  Rocket,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { InstanceBadge } from "@/components/status-badge";
import { api } from "@/lib/api";
import { timeAgo } from "@/lib/utils";
import type { MessagingInstance } from "@/lib/types";

type Step = "form" | "waiting";

export default function MessagingPage() {
  const [instances, setInstances] = useState<MessagingInstance[] | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [step, setStep] = useState<Step>("form");
  const [provider, setProvider] = useState("whatsapp");
  const [externalId, setExternalId] = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [turbo, setTurbo] = useState(false);
  const [turboConfirmOpen, setTurboConfirmOpen] = useState(false);

  useEffect(() => {
    void api.listInstances().then(setInstances).catch(() => setInstances([]));
  }, []);

  async function refreshStatuses() {
    setRefreshing(true);
    try {
      await api.refreshInstanceStatuses();
      setInstances(await api.listInstances());
    } catch {
      // mantém estado
    } finally {
      setRefreshing(false);
    }
  }

  function openConnect() {
    setStep("form");
    setProvider("whatsapp");
    setExternalId("");
    setError(null);
    setDialogOpen(true);
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (!externalId.trim()) {
      setError("Informe o identificador da instância");
      return;
    }
    setCreating(true);
    try {
      await api.createInstance(provider, externalId.trim());
      setStep("waiting");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Falha ao conectar");
    } finally {
      setCreating(false);
    }
  }

  async function finishConnect() {
    setInstances(await api.listInstances());
    setDialogOpen(false);
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-semibold">Instâncias de mensageria</h1>
          <p className="text-sm text-muted-foreground">
            WhatsApp (Evolution API) e Telegram
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => void refreshStatuses()}
            disabled={refreshing}
          >
            <RefreshCw
              className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`}
            />
            Atualizar status
          </Button>
          <Button onClick={openConnect}>
            <Plus className="h-4 w-4" aria-hidden />
            Nova instância
          </Button>
        </div>
      </div>

      <Card className="flex items-center justify-between gap-3 border-warning/40 bg-warning/5 p-4">
        <div className="flex items-center gap-2">
          <Rocket className="h-4 w-4 text-warning" />
          <div>
            <p className="text-sm font-medium">Modo Turbo</p>
            <p className="text-xs text-muted-foreground">
              Reduz o intervalo entre disparos de 15 min para 2 min em eventos
              (Black Friday, Prime Day).
            </p>
          </div>
        </div>
        <Switch
          checked={turbo}
          onCheckedChange={(v) => {
            if (v) setTurboConfirmOpen(true);
            else setTurbo(false);
          }}
          aria-label="Modo Turbo"
        />
      </Card>

      {instances === null ? (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-36 rounded-lg" />
          ))}
        </div>
      ) : instances.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
            <MessageCircle className="h-8 w-8 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">
              Conecte uma instância para começar a enviar ofertas.
            </p>
            <Button size="sm" onClick={openConnect}>
              Conectar agora
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {instances.map((instance) => {
            const disconnected =
              instance.status === "DISCONNECTED" ||
              instance.status === "FAILED";
            return (
              <motion.div
                key={instance.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.15 }}
              >
                <Card
                  className={
                    disconnected
                      ? "border-destructive/40"
                      : instance.status === "CONNECTING"
                        ? "border-warning/40"
                        : undefined
                  }
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="truncate font-medium">
                          {instance.externalId}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {instance.provider === "whatsapp"
                            ? "WhatsApp"
                            : "Telegram"}{" "}
                          · criada {timeAgo(instance.createdAt)}
                        </p>
                      </div>
                      <InstanceBadge status={instance.status} />
                    </div>
                    {disconnected && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="mt-3 w-full"
                        onClick={() => void refreshStatuses()}
                      >
                        <RefreshCw className="h-4 w-4" />
                        Reconectar
                      </Button>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          {step === "form" ? (
            <>
              <DialogHeader>
                <DialogTitle>Conectar nova instância</DialogTitle>
                <DialogDescription>
                  Informe o provider e o identificador da instância criada na
                  Evolution API ou no Telegram.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={onSubmit} className="space-y-4">
                {error && (
                  <div className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                    {error}
                  </div>
                )}
                <div className="space-y-1.5">
                  <Label htmlFor="provider">Provider</Label>
                  <Select value={provider} onValueChange={setProvider}>
                    <SelectTrigger id="provider" className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="whatsapp">WhatsApp</SelectItem>
                      <SelectItem value="telegram">Telegram</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="externalId">Identificador da instância</Label>
                  <Input
                    id="externalId"
                    value={externalId}
                    onChange={(e) => setExternalId(e.target.value)}
                    placeholder="nome-da-instancia"
                  />
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setDialogOpen(false)}
                  >
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={creating}>
                    {creating && (
                      <Loader2 className="animate-spin" aria-hidden />
                    )}
                    Conectar
                  </Button>
                </DialogFooter>
              </form>
            </>
          ) : (
            <>
              <DialogHeader>
                <DialogTitle>Aguardando leitura do QR code</DialogTitle>
                <DialogDescription>
                  Escaneie o código na Evolution API para emparelhar o número.
                </DialogDescription>
              </DialogHeader>
              <div className="flex flex-col items-center gap-4 py-4">
                <div className="flex h-44 w-44 items-center justify-center rounded-lg border bg-background">
                  <QrCode className="h-20 w-20 text-muted-foreground" />
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="animate-spin" aria-hidden />
                  Aguardando confirmação da conexão...
                </div>
              </div>
              <DialogFooter>
                <Button onClick={() => void finishConnect()}>
                  Concluir (já conectei)
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={turboConfirmOpen} onOpenChange={setTurboConfirmOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Ativar Modo Turbo?</DialogTitle>
            <DialogDescription>
              Os intervalos entre disparos cairão de 15 min para 2 min. Isso
              aumenta o risco de bloqueio no WhatsApp. Use apenas em eventos.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setTurboConfirmOpen(false)}
            >
              Cancelar
            </Button>
            <Button
              variant="default"
              onClick={() => {
                setTurbo(true);
                setTurboConfirmOpen(false);
              }}
            >
              Ativar turbo
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
