"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Activity, Bot, CreditCard, Gauge, LayoutDashboard, LogOut, MessageCircle, Settings, Tags, Users, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";

const GROUPS = [
  { title: "Operação", items: [
    ["/dashboard", "Dashboard", LayoutDashboard], ["/offers", "Ofertas", Tags], ["/groups", "Grupos", Users], ["/messaging", "Mensageria", MessageCircle],
  ]},
  { title: "Automação", items: [
    ["/automation", "Automações", Bot], ["/analytics", "Analytics", Gauge], ["/monitoring", "Monitoramento", Activity],
  ]},
  { title: "Conta", items: [
    ["/billing", "Assinatura", CreditCard], ["/settings", "Configurações", Settings],
  ]},
] as const;

export function AppSidebar() {
  const pathname = usePathname();
  const { user, logout } = useAuth();
  return (
    <aside className="hidden w-[248px] shrink-0 flex-col border-r bg-card lg:flex">
      <Link href="/dashboard" className="group flex h-16 items-center gap-3 border-b px-5">
        <div className="relative flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-[0_0_25px_rgba(91,141,239,.22)]"><Zap className="h-4 w-4" /></div>
        <div><div className="text-sm font-bold tracking-tight">Affiliate<span className="text-primary">OS</span></div><div className="text-[10px] uppercase tracking-[.18em] text-muted-foreground">Automation Cloud</div></div>
      </Link>
      <div className="border-b p-3"><div className="rounded-lg border bg-background/50 px-3 py-2"><div className="flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-success shadow-[0_0_8px_rgba(62,207,142,.65)]" /><span className="text-xs font-medium">Sistema operacional</span></div><p className="mt-1 text-[11px] text-muted-foreground">Todos os serviços respondendo</p></div></div>
      <nav className="flex-1 space-y-5 overflow-y-auto p-3">
        {GROUPS.map((group) => <div key={group.title}><p className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-[.16em] text-muted-foreground">{group.title}</p><div className="space-y-1">{group.items.map(([href,label,Icon]) => { const active = pathname === href || pathname.startsWith(`${href}/`); return <Link key={href} href={href} className={cn("group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all", active ? "bg-primary/10 text-primary ring-1 ring-primary/15" : "text-muted-foreground hover:bg-accent hover:text-foreground")}><Icon className="h-4 w-4 shrink-0" />{label}{active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-primary" />}</Link>; })}</div></div>)}
      </nav>
      <div className="border-t p-3"><div className="mb-2 flex items-center gap-3 rounded-lg px-2 py-2"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary text-xs font-bold">{(user?.email?.[0] ?? "A").toUpperCase()}</div><div className="min-w-0 flex-1"><p className="truncate text-xs font-semibold">{user?.tenantName ?? "Workspace"}</p><p className="truncate text-[11px] text-muted-foreground">{user?.email ?? ""}</p></div></div><Button variant="ghost" size="sm" className="w-full justify-start text-muted-foreground" onClick={() => void logout()}><LogOut className="mr-2 h-4 w-4" />Sair</Button></div>
    </aside>
  );
}
