import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import type {
  AuthUser,
  MarketplaceName,
  OfferNormalized,
} from '@affiliate-saas/shared-types';

export interface IngestResult {
  inserted: number;
  duplicates: number;
  dispatched: number;
}

@Injectable()
export class OffersService {
  private readonly logger = new Logger(OffersService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Persiste ofertas normalizadas (createMany + skipDuplicates) e enfileira
   * dispatch para os grupos do tenant cujo nicho casa com a oferta.
   */
  async ingest(
    offers: OfferNormalized[],
    tenantId: string,
    enqueueDispatch: (offerId: string, groupIds: string[]) => Promise<void>,
  ): Promise<IngestResult> {
    const result: IngestResult = { inserted: 0, duplicates: 0, dispatched: 0 };
    if (offers.length === 0) {
      return result;
    }

    const created = await this.prisma.offer.createMany({
      data: offers.map((o) => ({
        marketplace: o.marketplace,
        externalSku: o.externalSku,
        title: o.title,
        affiliateUrl: o.affiliateUrl,
        imageUrl: o.imageUrl,
        priceCents: o.priceCents,
        originalPriceCents: o.originalPriceCents,
        discountPercent: o.discountPercent,
        rating: o.rating,
        nicheTag: o.nicheTag,
        dedupeHash: o.dedupeHash,
      })),
      skipDuplicates: true,
    });

    result.inserted = created.count;
    result.duplicates = offers.length - created.count;

    if (created.count > 0) {
      const insertedOffers = await this.prisma.offer.findMany({
        where: { dedupeHash: { in: offers.map((o) => o.dedupeHash) } },
      });

      const groupsByNiche = await this.prisma.group.findMany({
        where: { tenantId, active: true },
      });

      for (const offer of insertedOffers) {
        const matchingGroups = groupsByNiche.filter((g) =>
          g.nicheTags.includes(offer.nicheTag),
        );
        if (matchingGroups.length > 0) {
          await enqueueDispatch(
            offer.id,
            matchingGroups.map((g) => g.id),
          );
          result.dispatched += matchingGroups.length;
        }
      }
    }

    return result;
  }

  async list(user: AuthUser, nicheTag?: string) {
    const offers = await this.prisma.offer.findMany({
      orderBy: { scrapedAt: 'desc' },
      take: 100,
      where: nicheTag ? { nicheTag } : undefined,
    });

    if (user.isAdminMaster) {
      return offers;
    }

    const dispatchJobs = await this.prisma.dispatchJob.findMany({
      where: { tenantId: user.tenantId },
      select: { offerId: true },
    });
    const dispatchedSet = new Set(dispatchJobs.map((d) => d.offerId));
    return offers.filter((o) => dispatchedSet.has(o.id));
  }

  async stats(marketplace: MarketplaceName, limit: number) {
    return this.prisma.offer.findMany({
      where: { marketplace },
      orderBy: { discountPercent: 'desc' },
      take: limit,
    });
  }
}
