import { Controller, Get, Logger, Post, Query } from '@nestjs/common';
import { OffersService } from './offers.service';
import { QueuesService } from '../queues/queues.service';
import { ShopeeService } from '../marketplaces/shopee/shopee.service';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { AdminMasterOnly } from '../../common/decorators/admin-master.decorator';
import type { AuthUser, NicheTag } from '@affiliate-saas/shared-types';

@Controller('offers')
export class OffersController {
  private readonly logger = new Logger(OffersController.name);

  constructor(
    private readonly offersService: OffersService,
    private readonly queuesService: QueuesService,
    private readonly shopeeService: ShopeeService,
  ) {}

  @Get()
  list(
    @CurrentUser() user: AuthUser,
    @Query('nicheTag') nicheTag?: NicheTag,
  ) {
    return this.offersService.list(user, nicheTag);
  }

  @AdminMasterOnly()
  @Post('mine/shopee')
  async mineShopee(@CurrentUser() user: AuthUser) {
    const mined = await this.shopeeService.mine();
    const result = await this.offersService.ingest(
      mined.offers,
      user.tenantId,
      async (offerId, groupIds) => {
        for (const groupId of groupIds) {
          await this.queuesService.enqueueDispatch({
            tenantId: user.tenantId,
            offerId,
            groupId,
          });
        }
      },
    );
    this.logger.log(`Mineração Shopee: ${JSON.stringify(result)}`);
    return result;
  }
}
