export const OFFER_MINING_QUEUE = 'offer-mining';
export const DISPATCH_QUEUE = 'dispatch';
export const BILLING_SYNC_QUEUE = 'billing-sync';
