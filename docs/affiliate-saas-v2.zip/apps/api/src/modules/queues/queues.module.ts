import { Global, Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { BullModule } from '@nestjs/bullmq';
import { QueuesService } from './queues.service';
import {
  OFFER_MINING_QUEUE,
  DISPATCH_QUEUE,
  BILLING_SYNC_QUEUE,
} from './queues.constants';

@Global()
@Module({
  imports: [
    BullModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        connection: {
          url: config.getOrThrow<string>('redisUrl'),
        },
      }),
    }),
    BullModule.registerQueue(
      { name: OFFER_MINING_QUEUE },
      { name: DISPATCH_QUEUE },
      { name: BILLING_SYNC_QUEUE },
    ),
  ],
  providers: [QueuesService],
  exports: [BullModule, QueuesService],
})
export class QueuesModule {}
