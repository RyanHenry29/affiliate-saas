import { Injectable } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { PrismaService } from '../../prisma/prisma.service';
import {
  DISPATCH_QUEUE,
  OFFER_MINING_QUEUE,
  BILLING_SYNC_QUEUE,
} from './queues.constants';
import type { DispatchJobInput } from '@affiliate-saas/shared-types';

@Injectable()
export class QueuesService {
  constructor(
    @InjectQueue(OFFER_MINING_QUEUE) private readonly miningQueue: Queue,
    @InjectQueue(DISPATCH_QUEUE) private readonly dispatchQueue: Queue,
    @InjectQueue(BILLING_SYNC_QUEUE) private readonly billingQueue: Queue,
    private readonly prisma: PrismaService,
  ) {}

  async enqueueMining(marketplace: string): Promise<void> {
    await this.miningQueue.add('mine', { marketplace });
  }

  /**
   * Cria o DispatchJob no banco (registro rastreável) e o enfileira com
   * delay anti-ban (30–90s). O worker atualiza o status deste registro.
   */
  async enqueueDispatch(input: {
    tenantId: string;
    offerId: string;
    groupId: string;
  }): Promise<void> {
    const delayMs = 30_000 + Math.floor(Math.random() * 60_000);
    const dispatchJob = await this.prisma.dispatchJob.create({
      data: {
        tenantId: input.tenantId,
        offerId: input.offerId,
        groupId: input.groupId,
        scheduledFor: new Date(Date.now() + delayMs),
      },
    });

    const jobInput: DispatchJobInput = {
      dispatchJobId: dispatchJob.id,
      tenantId: input.tenantId,
      offerId: input.offerId,
      groupId: input.groupId,
    };

    await this.dispatchQueue.add('dispatch', jobInput, {
      delay: delayMs,
      attempts: 3,
      backoff: { type: 'exponential', delay: 60_000 },
    });
  }

  async enqueueBillingSync(tenantId: string): Promise<void> {
    await this.billingQueue.add('sync', { tenantId });
  }
}
