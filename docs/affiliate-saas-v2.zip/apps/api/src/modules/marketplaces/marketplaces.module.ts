import { Module } from '@nestjs/common';
import { ShopeeModule } from './shopee/shopee.module';

@Module({
  imports: [ShopeeModule],
  exports: [ShopeeModule],
})
export class MarketplacesModule {}
