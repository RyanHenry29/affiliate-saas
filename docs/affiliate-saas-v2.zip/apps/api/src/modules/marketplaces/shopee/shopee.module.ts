import { Module } from '@nestjs/common';
import { ShopeeService } from './shopee.service';

@Module({
  providers: [ShopeeService],
  exports: [ShopeeService],
})
export class ShopeeModule {}
