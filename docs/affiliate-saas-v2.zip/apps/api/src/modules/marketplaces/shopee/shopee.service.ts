import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createHmac, createHash } from 'node:crypto';
import { NicheRouter } from '@affiliate-saas/shared-types';
import type {
  MarketplaceName,
  NicheTag,
  OfferNormalized,
} from '@affiliate-saas/shared-types';

const SHOPEE_OPEN_API_HOST = 'https://openapi.shopee.com';

interface ShopeeRawItem {
  item_id?: number;
  item_sku?: string;
  title?: string;
  price?: string | number;
  original_price?: string | number;
  rating_star?: string | number;
  image_url?: string;
  shop_id?: number;
  [key: string]: unknown;
}

export interface ShopeeMiningResult {
  inserted: number;
  skippedDuplicates: number;
  skippedByQuality: number;
  offers: OfferNormalized[];
}

@Injectable()
export class ShopeeService {
  private readonly logger = new Logger(ShopeeService.name);
  private readonly appId: string;
  private readonly appSecret: string;
  private readonly mockMode: boolean;

  constructor(private readonly config: ConfigService) {
    this.appId = this.config.get<string>('SHOPEE_APP_ID') ?? '';
    this.appSecret = this.config.get<string>('SHOPEE_APP_SECRET') ?? '';
    this.mockMode = this.config.get<string>('SHOPEE_MOCK_MINER') === 'true';
  }

  /**
   * Minerador principal. Busca ofertas de destaque/afiliados na API
   * oficial (Shopee Open Platform) e normaliza em OfferNormalized.
   */
  async mine(): Promise<ShopeeMiningResult> {
    const raw = this.mockMode
      ? this.mockRawItems()
      : await this.fetchFromShopee();

    const result: ShopeeMiningResult = {
      inserted: 0,
      skippedDuplicates: 0,
      skippedByQuality: 0,
      offers: [],
    };

    for (const item of raw) {
      const offer = this.normalize(item);
      if (!offer) {
        continue;
      }
      if (!this.passesQualityFilter(offer)) {
        result.skippedByQuality += 1;
        continue;
      }
      result.offers.push(offer);
    }

    return result;
  }

  private async fetchFromShopee(): Promise<ShopeeRawItem[]> {
    if (!this.appId || !this.appSecret) {
      throw new Error(
        'SHOPEE_APP_ID e SHOPEE_APP_SECRET são obrigatórios (ou ative SHOPEE_MOCK_MINER=true)',
      );
    }

    const timestamp = Math.floor(Date.now() / 1000).toString();
    const baseString = `${this.appId}${timestamp}`;
    const sign = createHmac('sha256', this.appSecret)
      .update(baseString)
      .digest('hex');

    // Endpoint da Shopee Open Platform (partner/affiliate). Ajuste o path
    // conforme a doc vigente da sua conta de afiliado.
    const path = '/open/v1/affiliate/product/search';
    const body = JSON.stringify({ page: 0, size: 50, sortType: 1 });

    const response = await fetch(`${SHOPEE_OPEN_API_HOST}${path}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Api-Key': this.appId,
        'X-Sign': sign,
        'X-Timestamp': timestamp,
      },
      body,
    });

    if (!response.ok) {
      throw new Error(`Shopee API ${response.status}: ${await response.text()}`);
    }

    const json = (await response.json()) as {
      data?: { items?: ShopeeRawItem[] };
    };
    return json.data?.items ?? [];
  }

  private normalize(item: ShopeeRawItem): OfferNormalized | null {
    const title = item.title ?? '';
    const sku =
      item.item_sku ?? (item.item_id ? String(item.item_id) : '') ?? '';
    if (!title || !sku) {
      return null;
    }

    const priceCents = this.toCents(item.price);
    const originalPriceCents = this.toCents(item.original_price);
    const discountPercent =
      originalPriceCents > 0
        ? Math.round(
            ((originalPriceCents - priceCents) / originalPriceCents) * 100,
          )
        : 0;

    const rating =
      typeof item.rating_star === 'number'
        ? item.rating_star
        : parseFloat(String(item.rating_star ?? '0')) || 0;

    const nicheTag = NicheRouter.classify(title);
    const affiliateUrl = this.buildAffiliateUrl(sku);

    return {
      marketplace: 'shopee',
      externalSku: sku,
      title,
      affiliateUrl,
      priceCents,
      originalPriceCents,
      discountPercent,
      rating,
      imageUrl: item.image_url,
      nicheTag,
      dedupeHash: this.dedupeHash('shopee', sku),
    };
  }

  /**
   * Filtro de qualidade exigido pelo produto:
   * > 20% de desconto E nota > 4.5 estrelas.
   */
  private passesQualityFilter(offer: OfferNormalized): boolean {
    return offer.discountPercent > 20 && offer.rating > 4.5;
  }

  private toCents(value: string | number | undefined): number {
    if (value === undefined || value === null) {
      return 0;
    }
    if (typeof value === 'number') {
      return Math.round(value * 100);
    }
    const parsed = parseFloat(value.replace(/[^\d.,-]/g, '').replace(',', '.'));
    return Number.isFinite(parsed) ? Math.round(parsed * 100) : 0;
  }

  private buildAffiliateUrl(sku: string): string {
    // URL afiliada: troque pelo padrão da sua conta Shopee Affiliate.
    return `https://shopee.com.br/product/${encodeURIComponent(sku)}?af_siteid=0&utm_campaign=${this.appId}&utm_source=${this.appId}`;
  }

  private dedupeHash(
    marketplace: MarketplaceName,
    externalSku: string,
  ): string {
    return createHash('sha256')
      .update(`${marketplace}:${externalSku}`)
      .digest('hex');
  }

  /** Modo mock: permite testar o pipeline sem credenciais reais. */
  private mockRawItems(): ShopeeRawItem[] {
    return [
      {
        item_id: 1001,
        item_sku: 'mock-fritadeira-air-fryer',
        title: 'Air Fryer 5L Digital Cozinha Fritadeira sem óleo',
        price: 219.9,
        original_price: 329.9,
        rating_star: 4.8,
        image_url: 'https://example.com/air-fryer.jpg',
      },
      {
        item_id: 1002,
        item_sku: 'mock-pneu-185-65-r15',
        title: 'Pneu 185/65 R15 Automotivo',
        price: 299,
        original_price: 419,
        rating_star: 4.7,
        image_url: 'https://example.com/pneu.jpg',
      },
      {
        item_id: 1003,
        item_sku: 'mock-racao-pet',
        title: 'Ração Premium para Cachorro 15kg',
        price: 189.9,
        original_price: 249.9,
        rating_star: 4.9,
        image_url: 'https://example.com/racao.jpg',
      },
      {
        item_id: 1004,
        item_sku: 'mock-fone-bluetooth',
        title: 'Fone de Ouvido Bluetooth TWS',
        price: 89.9,
        original_price: 99.9, // desconto de ~10% -> deve ser descartado pelo filtro
        rating_star: 4.4,
        image_url: 'https://example.com/fone.jpg',
      },
    ];
  }
}
