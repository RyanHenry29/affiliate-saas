import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import type { AuthUser } from '@affiliate-saas/shared-types';

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  listByTenant(user: AuthUser) {
    return this.prisma.user.findMany({
      where: { tenantId: user.tenantId },
      select: { id: true, email: true, role: true, createdAt: true },
    });
  }

  findById(id: string, user: AuthUser) {
    return this.prisma.user.findFirst({
      where: { id, tenantId: user.tenantId },
      select: { id: true, email: true, role: true, createdAt: true },
    });
  }

  async setRole(id: string, role: string, user: AuthUser) {
    if (!['MEMBER', 'OWNER'].includes(role)) {
      throw new NotFoundException('Role inválida');
    }
    const updated = await this.prisma.user.updateMany({
      where: { id, tenantId: user.tenantId },
      data: { role },
    });
    if (updated.count === 0) {
      throw new NotFoundException('Usuário não encontrado');
    }
    return { id, role };
  }
}
