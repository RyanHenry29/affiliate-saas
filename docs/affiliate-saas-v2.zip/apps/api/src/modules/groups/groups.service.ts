import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import type { AuthUser, NicheTag } from '@affiliate-saas/shared-types';

const ALLOWED_NICHES = new Set([
  'DONA_DE_CASA',
  'AUTOMOTIVO',
  'ELETRONICOS',
  'MODA',
  'BELEZA',
  'ESPORTES',
  'INFANTIL',
  'PETS',
  'GERAL',
]);

export class GroupDto {
  externalId!: string;
  name!: string;
  nicheTags!: NicheTag[];
  active?: boolean;
}

@Injectable()
export class GroupsService {
  constructor(private readonly prisma: PrismaService) {}

  list(user: AuthUser) {
    return this.prisma.group.findMany({
      where: { tenantId: user.tenantId },
    });
  }

  create(user: AuthUser, dto: GroupDto) {
    const nicheTags = this.sanitizeNiches(dto.nicheTags);
    return this.prisma.group.create({
      data: {
        tenantId: user.tenantId,
        externalId: dto.externalId,
        name: dto.name,
        nicheTags,
        active: dto.active ?? true,
      },
    });
  }

  async update(user: AuthUser, id: string, dto: Partial<GroupDto>) {
    const existing = await this.prisma.group.findFirst({
      where: { id, tenantId: user.tenantId },
    });
    if (!existing) {
      throw new NotFoundException('Grupo não encontrado');
    }
    return this.prisma.group.update({
      where: { id },
      data: {
        name: dto.name ?? existing.name,
        externalId: dto.externalId ?? existing.externalId,
        active: dto.active ?? existing.active,
        nicheTags: dto.nicheTags
          ? this.sanitizeNiches(dto.nicheTags)
          : existing.nicheTags,
      },
    });
  }

  async remove(user: AuthUser, id: string) {
    const existing = await this.prisma.group.findFirst({
      where: { id, tenantId: user.tenantId },
    });
    if (!existing) {
      throw new NotFoundException('Grupo não encontrado');
    }
    await this.prisma.group.delete({ where: { id } });
    return { id };
  }

  private sanitizeNiches(niches: NicheTag[]): NicheTag[] {
    const unique = Array.from(new Set(niches));
    return unique.filter((n) => ALLOWED_NICHES.has(n));
  }
}
