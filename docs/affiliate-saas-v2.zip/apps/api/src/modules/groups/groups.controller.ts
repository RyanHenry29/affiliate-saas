import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
} from '@nestjs/common';
import { GroupsService, GroupDto } from './groups.service';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import type { AuthUser } from '@affiliate-saas/shared-types';

@Controller('groups')
export class GroupsController {
  constructor(private readonly groupsService: GroupsService) {}

  @Get()
  list(@CurrentUser() user: AuthUser) {
    return this.groupsService.list(user);
  }

  @Post()
  create(@CurrentUser() user: AuthUser, @Body() dto: GroupDto) {
    return this.groupsService.create(user, dto);
  }

  @Patch(':id')
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser() user: AuthUser,
    @Body() dto: Partial<GroupDto>,
  ) {
    return this.groupsService.update(user, id, dto);
  }

  @Delete(':id')
  remove(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: AuthUser) {
    return this.groupsService.remove(user, id);
  }
}
