import { Module } from '@nestjs/common';
import { MessagingService } from './messaging.service';
import { MessagingController } from './messaging.controller';
import { EvolutionProvider } from './evolution.provider';

@Module({
  controllers: [MessagingController],
  providers: [MessagingService, EvolutionProvider],
  exports: [MessagingService, EvolutionProvider],
})
export class MessagingModule {}
