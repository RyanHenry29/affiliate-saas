import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { EvolutionProvider } from './evolution.provider';
import type { AuthUser } from '@affiliate-saas/shared-types';
import type { MessagingProvider } from './messaging-provider.interface';

@Injectable()
export class MessagingService {
  private readonly logger = new Logger(MessagingService.name);
  private provider: MessagingProvider;

  constructor(
    private readonly prisma: PrismaService,
    provider: EvolutionProvider,
  ) {
    this.provider = provider;
  }

  listInstances(user: AuthUser) {
    return this.prisma.messagingInstance.findMany({
      where: { tenantId: user.tenantId },
    });
  }

  async createInstance(user: AuthUser, providerName: string, externalId: string) {
    return this.prisma.messagingInstance.create({
      data: {
        tenantId: user.tenantId,
        provider: providerName,
        externalId,
      },
    });
  }

  async refreshInstanceStatuses(user: AuthUser) {
    const instances = await this.listInstances(user);
    const results: { id: string; status: string }[] = [];
    for (const instance of instances) {
      const status = await this.provider.getInstanceStatus(instance.externalId);
      await this.prisma.messagingInstance.update({
        where: { id: instance.id },
        data: { status },
      });
      results.push({ id: instance.id, status });
    }
    return results;
  }

  /** Envia uma oferta para um grupo do tenant (usado pelo worker via provider). */
  async sendOfferToGroup(
    tenantId: string,
    instanceExternalId: string,
    groupExternalId: string,
    text: string,
    mediaUrl?: string,
  ) {
    const instance = await this.prisma.messagingInstance.findFirst({
      where: { tenantId, externalId: instanceExternalId, status: 'CONNECTED' },
    });
    if (!instance) {
      throw new NotFoundException('Instância conectada não encontrada');
    }
    return this.provider.sendToGroup({
      tenantId,
      instanceExternalId,
      groupExternalId,
      text,
      mediaUrl,
    });
  }
}
