import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import type {
  DispatchResult,
  MessagingProvider,
} from './messaging-provider.interface';

interface EvolutionInstance {
  instanceName: string;
  status: string;
}

@Injectable()
export class EvolutionProvider implements MessagingProvider {
  readonly providerName = 'whatsapp-unofficial' as const;

  private readonly logger = new Logger(EvolutionProvider.name);
  private readonly baseUrl: string;
  private readonly apiKey: string;

  constructor(private readonly config: ConfigService) {
    this.baseUrl =
      this.config.get<string>('evolutionApi.url') ?? 'http://localhost:8080';
    this.apiKey = this.config.get<string>('evolutionApi.key') ?? '';
  }

  async sendToGroup(params: {
    tenantId: string;
    instanceExternalId: string;
    groupExternalId: string;
    text: string;
    mediaUrl?: string;
  }): Promise<DispatchResult> {
    const { instanceExternalId, groupExternalId, text, mediaUrl } = params;

    try {
      if (mediaUrl) {
        await this.sendMedia(instanceExternalId, groupExternalId, mediaUrl, text);
      } else {
        await this.sendText(instanceExternalId, groupExternalId, text);
      }
      return { externalMessageId: null, status: 'SENT' };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      this.logger.error(`Falha no envio: ${message}`);
      if (/429|rate|limit|too many/i.test(message)) {
        return { externalMessageId: null, status: 'RATE_LIMITED', errorReason: message };
      }
      return { externalMessageId: null, status: 'FAILED', errorReason: message };
    }
  }

  async getInstanceStatus(
    instanceExternalId: string,
  ): Promise<'CONNECTED' | 'DISCONNECTED' | 'ERROR'> {
    try {
      const response = await fetch(
        `${this.baseUrl}/instance/connectionState/${instanceExternalId}`,
        {
          headers: { apikey: this.apiKey },
        },
      );
      if (!response.ok) {
        return 'ERROR';
      }
      const data = (await response.json()) as EvolutionInstance;
      return data.status === 'open' ? 'CONNECTED' : 'DISCONNECTED';
    } catch (error) {
      this.logger.error(`Falha ao checar instância: ${String(error)}`);
      return 'ERROR';
    }
  }

  private async sendText(
    instanceExternalId: string,
    groupExternalId: string,
    text: string,
  ): Promise<void> {
    const response = await fetch(
      `${this.baseUrl}/message/sendText/${instanceExternalId}`,
      {
        method: 'POST',
        headers: { apikey: this.apiKey, 'Content-Type': 'application/json' },
        body: JSON.stringify({ number: groupExternalId, text }),
      },
    );
    if (!response.ok) {
      throw new Error(`sendText ${response.status}`);
    }
  }

  private async sendMedia(
    instanceExternalId: string,
    groupExternalId: string,
    mediaUrl: string,
    caption: string,
  ): Promise<void> {
    const response = await fetch(
      `${this.baseUrl}/message/sendMedia/${instanceExternalId}`,
      {
        method: 'POST',
        headers: { apikey: this.apiKey, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          number: groupExternalId,
          mediatype: 'image',
          media: mediaUrl,
          caption,
        }),
      },
    );
    if (!response.ok) {
      throw new Error(`sendMedia ${response.status}`);
    }
  }
}
