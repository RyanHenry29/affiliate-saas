import { Controller, Get, Post, Body } from '@nestjs/common';
import { IsString } from 'class-validator';
import { MessagingService } from './messaging.service';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import type { AuthUser } from '@affiliate-saas/shared-types';

class CreateInstanceDto {
  @IsString()
  provider!: string;

  @IsString()
  externalId!: string;
}

@Controller('messaging')
export class MessagingController {
  constructor(private readonly messagingService: MessagingService) {}

  @Get('instances')
  listInstances(@CurrentUser() user: AuthUser) {
    return this.messagingService.listInstances(user);
  }

  @Post('instances')
  createInstance(@CurrentUser() user: AuthUser, @Body() dto: CreateInstanceDto) {
    return this.messagingService.createInstance(user, dto.provider, dto.externalId);
  }

  @Post('instances/refresh')
  refreshStatuses(@CurrentUser() user: AuthUser) {
    return this.messagingService.refreshInstanceStatuses(user);
  }
}
