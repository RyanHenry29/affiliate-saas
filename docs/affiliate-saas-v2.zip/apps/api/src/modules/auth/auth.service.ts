import {
  ConflictException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import { createHash } from 'node:crypto';
import { PrismaService } from '../../prisma/prisma.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import type { AuthTokens, AuthUserResponse } from '@affiliate-saas/contracts';
import type { JwtPayload } from './strategies/jwt.strategy';
import type { AuthUser } from '@affiliate-saas/shared-types';

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
    private readonly config: ConfigService,
  ) {}

  async register(
    dto: RegisterDto,
  ): Promise<AuthTokens & { user: AuthUserResponse }> {
    const existing = await this.prisma.user.findUnique({
      where: { email: dto.email },
    });
    if (existing) {
      throw new ConflictException('E-mail já cadastrado');
    }

    const passwordHash = await bcrypt.hash(dto.password, 12);

    const tenant = await this.prisma.tenant.create({
      data: {
        name: dto.tenantName,
        users: {
          create: {
            email: dto.email,
            passwordHash,
            role: 'OWNER',
          },
        },
      },
    });

    const user = await this.prisma.user.findUniqueOrThrow({
      where: { email: dto.email },
    });

    const tokens = await this.issueTokens(
      user.id,
      user.email,
      user.tenantId,
      user.role,
    );
    return {
      ...tokens,
      user: this.toResponse(user, false, tenant.name),
    };
  }

  async login(
    dto: LoginDto,
  ): Promise<AuthTokens & { user: AuthUserResponse }> {
    const user = await this.prisma.user.findUnique({
      where: { email: dto.email },
      include: { tenant: true },
    });
    if (!user || !(await bcrypt.compare(dto.password, user.passwordHash))) {
      throw new UnauthorizedException('Credenciais inválidas');
    }

    const tokens = await this.issueTokens(
      user.id,
      user.email,
      user.tenantId,
      user.role,
    );
    return {
      ...tokens,
      user: this.toResponse(user, user.tenant.isAdminMaster, user.tenant.name),
    };
  }

  async refresh(refreshToken: string): Promise<AuthTokens> {
    let payload: JwtPayload;
    try {
      payload = await this.jwtService.verifyAsync<JwtPayload>(refreshToken, {
        secret: this.config.getOrThrow<string>('jwt.refreshSecret'),
      });
    } catch {
      throw new UnauthorizedException('Refresh token inválido ou expirado');
    }

    const stored = await this.prisma.refreshToken.findUnique({
      where: { tokenHash: this.hashToken(refreshToken) },
    });
    if (
      !stored ||
      stored.revokedAt ||
      stored.expiresAt < new Date() ||
      stored.userId !== payload.sub
    ) {
      throw new UnauthorizedException('Refresh token revogado');
    }

    const user = await this.prisma.user.findUniqueOrThrow({
      where: { id: payload.sub },
    });
    return this.issueTokens(user.id, user.email, user.tenantId, user.role);
  }

  async logout(refreshToken: string): Promise<void> {
    await this.prisma.refreshToken.updateMany({
      where: { tokenHash: this.hashToken(refreshToken), revokedAt: null },
      data: { revokedAt: new Date() },
    });
  }

  async getMe(user: AuthUser): Promise<AuthUserResponse> {
    const tenant = await this.prisma.tenant.findUniqueOrThrow({
      where: { id: user.tenantId },
    });
    const record = await this.prisma.user.findUniqueOrThrow({
      where: { id: user.id },
    });
    return this.toResponse(record, user.isAdminMaster, tenant.name);
  }

  private async issueTokens(
    userId: string,
    email: string,
    tenantId: string,
    role: string,
  ): Promise<AuthTokens> {
    const accessPayload: JwtPayload = { sub: userId, email, tenantId, role };
    const accessToken = await this.jwtService.signAsync(accessPayload, {
      secret: this.config.getOrThrow<string>('jwt.secret'),
      expiresIn: this.config.get<string>('jwt.expiresIn'),
    });

    const refreshExpiresIn = this.config.get<string>(
      'jwt.refreshExpiresIn',
    ) ?? '7d';
    const refreshToken = await this.jwtService.signAsync(
      { sub: userId, email, tenantId, role },
      {
        secret: this.config.getOrThrow<string>('jwt.refreshSecret'),
        expiresIn: refreshExpiresIn,
      },
    );

    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    await this.prisma.refreshToken.create({
      data: {
        userId,
        tokenHash: this.hashToken(refreshToken),
        expiresAt,
      },
    });

    return { accessToken, refreshToken, accessTokenExpiresIn: 15 * 60 };
  }

  private hashToken(token: string): string {
    return createHash('sha256').update(token).digest('hex');
  }

  private toResponse(
    user: { id: string; email: string; tenantId: string; role: string },
    isAdminMaster: boolean,
    tenantName: string,
  ): AuthUserResponse {
    return {
      id: user.id,
      email: user.email,
      tenantId: user.tenantId,
      role: user.role,
      isAdminMaster,
      tenantName,
    };
  }
}
