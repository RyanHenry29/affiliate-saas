import {
  Injectable,
  ExecutionContext,
  ForbiddenException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ROLES_KEY } from '../decorators/roles.decorator';
import { ADMIN_MASTER_ONLY_KEY } from '../decorators/admin-master.decorator';

@Injectable()
export class RolesGuard {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredRoles = this.reflector.getAllAndOverride<string[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    const adminMasterOnly = this.reflector.getAllAndOverride<boolean>(
      ADMIN_MASTER_ONLY_KEY,
      [context.getHandler(), context.getClass()],
    );

    const request = context.switchToHttp().getRequest<{ user?: { role?: string; isAdminMaster?: boolean } }>();
    const user = request.user;

    if (adminMasterOnly) {
      if (!user?.isAdminMaster) {
        throw new ForbiddenException('Somente Admin Master');
      }
      return true;
    }

    if (!requiredRoles || requiredRoles.length === 0) {
      return true;
    }

    if (user?.isAdminMaster) {
      return true;
    }

    if (!requiredRoles.includes(user?.role ?? '')) {
      throw new ForbiddenException('Acesso negado');
    }
    return true;
  }
}
