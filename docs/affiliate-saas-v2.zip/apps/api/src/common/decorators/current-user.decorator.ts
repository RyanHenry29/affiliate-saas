import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import type { AuthUser } from '@affiliate-saas/shared-types';

export interface AuthenticatedRequest {
  user: AuthUser;
}

export const CurrentUser = createParamDecorator(
  (data: keyof AuthUser | undefined, ctx: ExecutionContext) => {
    const request = ctx.switchToHttp().getRequest<AuthenticatedRequest>();
    const user = request.user;
    return data ? user?.[data] : user;
  },
);
