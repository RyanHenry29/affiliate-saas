import { SetMetadata } from '@nestjs/common';

export const ADMIN_MASTER_ONLY_KEY = 'adminMasterOnly';
export const AdminMasterOnly = () => SetMetadata(ADMIN_MASTER_ONLY_KEY, true);
