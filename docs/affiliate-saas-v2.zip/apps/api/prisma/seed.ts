import {
  PrismaClient,
  Prisma,
  PlanTier,
  SubscriptionStatus,
} from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  const masterEmail = process.env.ADMIN_MASTER_EMAIL ?? 'admin@senaflow.local';
  const masterPassword = process.env.ADMIN_MASTER_PASSWORD ?? 'ChangeMe!123';

  const existing = await prisma.tenant.findFirst({ where: { isAdminMaster: true } });
  if (!existing) {
    const passwordHash = await bcrypt.hash(masterPassword, 12);

    const tenant = await prisma.tenant.create({
      data: {
        name: 'Senaflow Master',
        isAdminMaster: true,
        users: {
          create: [
            {
              email: masterEmail,
              passwordHash,
              role: 'ADMIN_MASTER',
            },
          ],
        },
        subscription: {
          create: {
            plan: PlanTier.AGENCY,
            status: SubscriptionStatus.ACTIVE,
            externalCustomerId: 'admin-master',
            currentPeriodEnd: new Date('2099-01-01'),
          },
        },
      },
    });

    console.log(`Admin master criado: tenant=${tenant.id} email=${masterEmail}`);
  } else {
    console.log(`Admin master já existe: tenant=${existing.id}`);
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
