# Prompts de UI por tela

O design system base já está em `CLAUDE.md` na raiz (carregado automaticamente pelo
Claude Code). Cole aqui apenas o prompt da tela que for gerar/ajustar — não recole o
design system.

As 5 telas abaixo já existem em `apps/web/src/app/(dashboard)/`. Use estes prompts
para **evoluir** as telas existentes (novas features, refinos), não para regenerá-las
do zero — regenerar do zero descarta o trabalho já feito.

---

## Dashboard (`/dashboard`)

Já implementado: KPIs com count-up na primeira carga da sessão, empty state sem
instância conectada, gráfico de disparos por hora (Recharts), lista de instâncias
com refresh manual.

Pendente / próximos incrementos sugeridos:
- Feed de eventos recentes (últimos 10 disparos/erros) como lista compacta tipo log,
  fonte mono para timestamp, ícone de severidade.
- Ligar KPIs "disparos enviados hoje" e "taxa de erro (24h)" a dados reais (hoje
  hardcoded em 0) assim que o endpoint existir.
- Dot de status animado na lista de instâncias **só quando o estado muda** (regra de
  motion #4) — hoje o `InstanceBadge` é estático.

## Tabela de Ofertas (`/offers`)

Tela de maior densidade de dados do sistema — priorize escaneabilidade.

- Tabela virtualizada (`@tanstack/react-virtual`) — assuma milhares de linhas.
- Colunas: thumbnail (lazy load), título, marketplace (badge por marketplace, não por
  status), preço atual + delta vs. histórico (verde se caiu, vermelho se subiu, fonte
  mono), nicheTag, status, ações (postar agora / descartar).
- Filtros: marketplace, nicheTag, status, busca por título (debounce 300ms).
- Ao filtrar: fade curto (150ms) no conteúdo, **não** reanimar linha por linha (tabela
  grande = regra de motion #2 proíbe stagger acima de 15 itens).
- Linha nova via realtime: insere no topo com highlight de background que decai em
  1.5s.
- Ação "descartar": fade + collapse de altura via `layout` do Framer Motion.
- Não anime a tabela inteira ao montar a página.

## Instâncias WhatsApp/Telegram (`/messaging`)

Desconexão de instância é o principal ponto de falha operacional — hierarquia visual
de status importa mais que qualquer outra coisa nesta tela.

- Grid de cards: nome/número, provider, status com dot grande, grupos vinculados
  (contagem), última atividade.
- Card desconectado: borda âmbar/vermelha conforme severidade, botão "Reconectar" em
  primeiro plano.
- Fluxo de nova instância: modal com steps (nome → provider → QR code / pairing
  code). No step de QR, indicador de loading real (está de fato esperando webhook).
- Confirmação de conexão: troca de ícone + cor, sem confetti.
- Toggle "Modo Turbo": com confirmação antes de ativar (mudança operacional agressiva,
  não deve ser um clique acidental).
- Não anime o grid inteiro se houver mais de ~8 instâncias (plano Agency pode ter
  dezenas).

## Billing (`/billing` e `/admin/billing`)

- Card do plano atual: nome, preço, `currentPeriodEnd`, status (mesmo badge do
  dashboard).
- Se `PAST_DUE`: banner persistente no topo em **qualquer** tela até o pagamento ser
  resolvido, cor âmbar/vermelho conforme dias de atraso, CTA direto. **Sem pulse
  contínuo** — a cor e a posição já comunicam urgência.
- Grid de comparação de planos (3 colunas), plano atual destacado com borda, sem
  gradientes.
- Histórico de faturas: tabela simples, sem animação de entrada.

## Grupos (`/groups`)

Vinculação grupo ↔ nicheTag. Melhor evoluída depois que o módulo `offers` tiver
dedupe/scoring funcionando — sem nicho classificado de verdade, a tela fica mockada
demais para validar UX real.

---

## Notas de uso

1. Não pule o `CLAUDE.md`. Sem ele, cada tela gerada em sessão separada diverge em
   paleta/spacing/motion.
2. Ordem sugerida (do `README.md` do repo): `auth` → `messaging` MVP → `billing` →
   `admin-panel`. UI bonita de uma tela sem backend funcional é dívida técnica
   disfarçada de progresso.
3. Scraping do Mercado Livre está fora da v1 (risco legal) — não gere UI que dependa
   disso como fonte de oferta.
