# affiliate-saas — esqueleto

## Decisões arquiteturais

- **Monolito modular** (NestJS) + workers separados (BullMQ), não microsserviços reais.
  Justificativa: no MVP, o custo operacional de service mesh/observabilidade distribuída
  não se paga. Separar em serviços reais só quando houver necessidade comprovada de
  escala independente (ex.: workers de scraping saturando enquanto API está ociosa).
- **Multi-tenant via `tenantId` em todas as tabelas** (row-level, não schema-per-tenant).
  Mais simples de operar em <10k tenants; migrar para schema-per-tenant ou DB-per-tenant
  apenas se houver requisito de isolamento forte (compliance) ou tenants "barulhentos".
- **Gateway de mensagens desacoplado**: módulo `messaging` fala com Evolution API via
  interface (`MessagingProvider`), nunca diretamente nos controllers de negócio.
  Isso permite trocar o provider sem reescrever `offers`/`groups`/`billing`.

## Riscos que você precisa decidir ANTES de codar a Fase 2

1. **WhatsApp via Baileys/Evolution API não é suportado pela Meta.** Contas de clientes
   serão banidas com frequência não trivial. Isso é risco de produto, não bug.
   Alternativa: WhatsApp Business Cloud API oficial (mais caro, mais limitado em
   disparo para grupos, mas sem risco de ban em massa).
2. **Scraping do Mercado Livre via cookies de sessão de terceiros** é a integração
   de maior risco legal do projeto. Não há API pública de afiliados aberta.
   Decisão recomendada: **não implementar na v1**; usar apenas marketplaces com
   API oficial de afiliados (Shopee, Amazon PA-API, AliExpress, Awin).
3. **LGPD**: instâncias de WhatsApp de clientes passam por sua infraestrutura →
   você processa conteúdo de terceiros. Precisa de DPA com clientes, política de
   retenção de logs, e criptografia em repouso para `MessagingInstance` credentials.

## Setup local

```bash
cp .env.example .env
cd infra/docker && docker compose up -d
pnpm install
pnpm --filter api prisma migrate dev
pnpm dev:api
```

## Próximos passos (ordem recomendada)

1. `modules/auth` — JWT + refresh + guard de tenant + guard de role (ADMIN_MASTER bypass billing)
2. `modules/billing` — webhook handler (Stripe ou Mercado Pago) + job de suspensão por inadimplência
3. `modules/marketplaces/shopee` — client oficial + normalização de `Offer`
4. `modules/queues` — BullMQ: fila `offer-mining`, fila `dispatch`, fila `billing-sync`
5. `modules/messaging` — interface `MessagingProvider` + implementação Telegram primeiro
   (menor risco, valida o pipeline) antes de Evolution API
