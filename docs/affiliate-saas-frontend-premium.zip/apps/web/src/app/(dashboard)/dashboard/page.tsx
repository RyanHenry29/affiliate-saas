"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Activity, ArrowUpRight, Bot, CheckCircle2, Clock3, MessageCircle, RefreshCw, Send, Settings2, Tags, TrendingUp, WifiOff, Zap } from "lucide-react";
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { CountUp } from "@/components/count-up";
import { InstanceBadge } from "@/components/status-badge";
import { api } from "@/lib/api";
import { timeAgo } from "@/lib/utils";
import type { MessagingInstance, Offer } from "@/lib/types";

const HOURLY_DATA = [{hour:"00h",count:3},{hour:"04h",count:7},{hour:"08h",count:24},{hour:"12h",count:41},{hour:"16h",count:35},{hour:"20h",count:58},{hour:"23h",count:22}];
const ACTIVITY = [
  ["Oferta processada", "Shopee · desconto validado", "2 min"],
  ["Disparo concluído", "Grupo Achadinhos · 18 membros", "5 min"],
  ["Instância sincronizada", "WhatsApp principal", "9 min"],
  ["Cupom validado", "Código ativo por 6h", "14 min"],
];

export default function DashboardPage() {
  const [offers, setOffers] = useState<Offer[] | null>(null); const [instances, setInstances] = useState<MessagingInstance[] | null>(null); const [refreshing,setRefreshing]=useState(false);
  useEffect(()=>{void api.listOffers().then(setOffers).catch(()=>setOffers([])); void api.listInstances().then(setInstances).catch(()=>setInstances([]));},[]);
  const todayOffers=useMemo(()=> (offers??[]).filter(o=>new Date(o.scrapedAt).toDateString()===new Date().toDateString()).length,[offers]);
  const connected=useMemo(()=> (instances??[]).filter(i=>i.status==="CONNECTED").length,[instances]); const loading=offers===null||instances===null;
  async function refreshStatuses(){setRefreshing(true);try{await api.refreshInstanceStatuses();setInstances(await api.listInstances())}catch{}finally{setRefreshing(false)}}
  const kpis=[
    ["Ofertas hoje",todayOffers,Tags,"+18%", "text-primary"], ["Disparos enviados",1248,Send,"+12%","text-success"], ["Cliques rastreados",3876,TrendingUp,"+24%","text-primary"], ["Erros 24h",2,WifiOff,"-31%","text-warning"]
  ] as const;
  return <div className="space-y-6">
    <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="eyebrow">Centro de operações</p><h1 className="mt-1 text-2xl font-bold tracking-tight">Dashboard</h1><p className="mt-1 text-sm text-muted-foreground">Visão geral da sua operação de afiliados em tempo real.</p></div><div className="flex gap-2"><Button variant="outline" size="sm" onClick={()=>void refreshStatuses()} disabled={refreshing}><RefreshCw className={`mr-2 h-4 w-4 ${refreshing?"animate-spin":""}`}/>Atualizar</Button><Button size="sm" asChild><Link href="/offers"><Zap className="mr-2 h-4 w-4"/>Nova automação</Link></Button></div></div>
    {loading?<div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{Array.from({length:4}).map((_,i)=><Skeleton key={i} className="h-[122px] rounded-xl"/>)}</div>:<div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{kpis.map(([label,value,Icon,trend,accent],i)=><motion.div key={label} initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} transition={{delay:i*.04}}><Card className="surface-hover"><CardContent className="p-5"><div className="flex items-start justify-between"><div><p className="text-xs text-muted-foreground">{label}</p><p className="metric-value mt-2"><CountUp value={value}/></p></div><div className={`rounded-lg bg-secondary p-2 ${accent}`}><Icon className="h-4 w-4"/></div></div><div className="mt-3 flex items-center gap-1 text-[11px]"><span className={trend.startsWith("-")?"text-success":"text-success"}>{trend}</span><span className="text-muted-foreground">vs. período anterior</span></div></CardContent></Card></motion.div>)}</div>}
    <div className="grid gap-4 xl:grid-cols-[minmax(0,1.7fr)_minmax(300px,.8fr)]">
      <Card><CardHeader className="flex-row items-center justify-between space-y-0"><div><CardTitle className="text-base">Atividade de disparos</CardTitle><p className="mt-1 text-xs text-muted-foreground">Volume processado nas últimas 24 horas</p></div><span className="flex items-center gap-1.5 text-xs text-success"><span className="h-1.5 w-1.5 rounded-full bg-success"/>Ao vivo</span></CardHeader><CardContent className="h-72"><ResponsiveContainer width="100%" height="100%"><LineChart data={HOURLY_DATA}><XAxis dataKey="hour" stroke="#7d8796" fontSize={11} tickLine={false} axisLine={false}/><YAxis stroke="#7d8796" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} width={28}/><Tooltip contentStyle={{background:"#101319",border:"1px solid #262c35",borderRadius:10,fontSize:12}}/><Line type="monotone" dataKey="count" stroke="#5b8def" strokeWidth={2.5} dot={false} activeDot={{r:4}}/></LineChart></ResponsiveContainer></CardContent></Card>
      <Card><CardHeader><CardTitle className="text-base">Atalhos rápidos</CardTitle></CardHeader><CardContent className="grid gap-2">{[["Mineração","Buscar novas ofertas",Tags,"/offers"],["Mensageria","Conectar instância",MessageCircle,"/messaging"],["Grupos","Configurar destinos",Activity,"/groups"],["IA Copywriter","Criar template",Bot,"/offers"]].map(([title,sub,Icon,href])=><Link key={title as string} href={href as string} className="group flex items-center gap-3 rounded-lg border p-3 transition hover:border-primary/30 hover:bg-accent/40"><div className="rounded-lg bg-secondary p-2"><Icon className="h-4 w-4 text-primary"/></div><div className="min-w-0 flex-1"><p className="text-sm font-medium">{title}</p><p className="text-[11px] text-muted-foreground">{sub}</p></div><ArrowUpRight className="h-4 w-4 text-muted-foreground transition group-hover:text-primary"/></Link>)}</CardContent></Card>
    </div>
    <div className="grid gap-4 xl:grid-cols-[minmax(0,1.3fr)_minmax(320px,.7fr)]">
      <Card><CardHeader className="flex-row items-center justify-between space-y-0"><div><CardTitle className="text-base">Atividade recente</CardTitle><p className="mt-1 text-xs text-muted-foreground">Eventos importantes da plataforma</p></div><Button variant="ghost" size="sm">Ver tudo</Button></CardHeader><CardContent className="space-y-1">{ACTIVITY.map(([title,sub,time],i)=><div key={title} className="flex items-center gap-3 rounded-lg px-2 py-3 hover:bg-accent/40"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-success/10 text-success"><CheckCircle2 className="h-4 w-4"/></div><div className="min-w-0 flex-1"><p className="text-sm font-medium">{title}</p><p className="truncate text-xs text-muted-foreground">{sub}</p></div><span className="text-[11px] text-muted-foreground">{time}</span></div>)}</CardContent></Card>
      <Card><CardHeader className="flex-row items-center justify-between space-y-0"><div><CardTitle className="text-base">Instâncias</CardTitle><p className="mt-1 text-xs text-muted-foreground">Saúde das conexões</p></div><Button variant="ghost" size="icon" onClick={()=>void refreshStatuses()} disabled={refreshing}><RefreshCw className={`h-4 w-4 ${refreshing?"animate-spin":""}`}/></Button></CardHeader><CardContent className="space-y-2">{(instances??[]).length===0?<div className="rounded-lg border border-warning/30 bg-warning/5 p-4"><p className="text-sm font-medium">Nenhuma instância conectada</p><p className="mt-1 text-xs text-muted-foreground">Conecte um WhatsApp ou Telegram para iniciar os disparos.</p><Button className="mt-3" size="sm" asChild><Link href="/messaging">Conectar agora</Link></Button></div>:(instances??[]).map(instance=><div key={instance.id} className="flex items-center gap-3 rounded-lg border p-3"><div className="min-w-0 flex-1"><p className="truncate text-sm font-medium">{instance.externalId}</p><p className="text-[11px] text-muted-foreground">{instance.provider==="whatsapp"?"WhatsApp":"Telegram"} · {timeAgo(instance.createdAt)}</p></div><InstanceBadge status={instance.status}/></div>)}</CardContent></Card>
    </div>
    <Card className="overflow-hidden border-primary/20 bg-primary/[.035]"><CardContent className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-start gap-3"><div className="rounded-lg bg-primary/10 p-2 text-primary"><Settings2 className="h-5 w-5"/></div><div><p className="text-sm font-semibold">Otimize sua operação</p><p className="mt-1 max-w-2xl text-xs leading-5 text-muted-foreground">Configure regras por nicho, janelas de envio, templates de copy e grupos de destino para deixar o sistema funcionando praticamente sozinho.</p></div></div><Button variant="outline" size="sm" asChild><Link href="/groups">Configurar operação<ArrowUpRight className="ml-2 h-4 w-4"/></Link></Button></CardContent></Card>
  </div>;
}
