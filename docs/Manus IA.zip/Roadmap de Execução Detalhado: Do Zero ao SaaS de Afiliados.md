# Roadmap de Execução Detalhado: Do Zero ao SaaS de Afiliados

Este documento detalha as etapas práticas para a construção do seu sistema de automação. Dividi o projeto em **6 etapas principais**, organizadas de forma que você tenha um sistema funcional o mais rápido possível (MVP) antes de adicionar as camadas mais complexas.

---

## Etapa 1: Fundação e Infraestrutura (A Base)
Nesta fase, você prepara o ambiente onde o sistema irá morar.
*   **Servidor (VPS):** Contratação de uma VPS (Ubuntu 22.04+). Recomendo máquinas com pelo menos 2GB de RAM para rodar a Evolution API com folga.
*   **Banco de Dados:** Configuração do PostgreSQL ou MySQL para armazenar dados de usuários, grupos e histórico de ofertas.
*   **Autenticação:** Implementação do sistema de Login/Senha com níveis de acesso (Admin vs. Usuário).
*   **Dashboard Base:** Criação da interface inicial (Layout) onde os menus laterais estarão presentes.

## Etapa 2: O Motor de Mineração (Os "Olhos")
Aqui é onde o sistema aprende a buscar as ofertas.
*   **Scrapers de Marketplaces:** Desenvolvimento de scripts (Python/Node) para monitorar páginas de "Ofertas do Dia" da Amazon, Shopee e Mercado Livre.
*   **Integração de APIs Oficiais:** Configuração das chaves de API da Shopee e AliExpress para busca estruturada de produtos.
*   **Filtros de Entrada:** Implementação da lógica que lê o produto e decide se ele presta (ex: "Tem mais de 20% de desconto?").

## Etapa 3: Motor de Links e Mídia (O "Cérebro")
Transformação do produto bruto em uma oferta pronta para o afiliado.
*   **Conversor de Links:** Lógica para pegar o link original e injetar a `Tag de Afiliado` do usuário.
*   **Processamento de Imagens:** Download automático da imagem principal do produto e, opcionalmente, adição de uma marca d'água ou borda personalizada.
*   **Template Engine:** Sistema que monta o texto final (ex: "🔥 *Título* - R$ Preço - Link") baseado no que o usuário configurou no grupo.

## Etapa 4: Gateway de Mensagens (A "Voz")
Conexão com o mundo externo.
*   **Instalação da Evolution API:** Configuração do serviço que gerencia o WhatsApp via Docker na sua VPS.
*   **Conexão QR Code:** Interface para o usuário escanear o código e "logar" o WhatsApp dele no seu sistema.
*   **Telegram Bot:** Integração com a API do Telegram para envio em canais.
*   **Sistema de Filas (Queue):** Uso de **Redis + BullMQ** para garantir que, se você tiver 100 mensagens para enviar, elas saiam uma por uma sem travar o sistema.

## Etapa 5: Automação e Agendamento (O "Relógio")
A inteligência que faz tudo rodar sozinho.
*   **Mix de Marketplaces:** Lógica de sorteio aleatório para alternar entre lojas (ex: 10:00 Amazon, 10:15 Shopee).
*   **Janelas de Horário:** Filtro que impede o envio de madrugada (ex: só postar entre 08h e 22h).
*   **Painel de Grupos:** Tela para o usuário criar grupos, selecionar quais lojas quer e definir os filtros específicos de cada grupo.

## Etapa 6: Camada SaaS e Admin (O "Negócio")
Transformando a ferramenta em um produto vendável.
*   **Integração de Pagamento:** Conexão com Stripe ou Mercado Pago para gerenciar assinaturas.
*   **Painel Admin Master:** Sua tela secreta para ver quantos usuários existem, quem pagou, e liberar acesso ilimitado para você mesmo.
*   **Multi-tenancy:** Garantir que o Usuário A nunca veja os grupos ou o WhatsApp do Usuário B.

---

## Resumo do Esforço Estimado

| Etapa | Complexidade | Foco Principal |
| :--- | :--- | :--- |
| **1. Fundação** | Baixa | Segurança e Estrutura |
| **2. Mineração** | Alta | Captura de dados e precisão |
| **3. Links/Mídia** | Média | Geração de comissão |
| **4. Mensagens** | Média | Estabilidade da conexão |
| **5. Automação** | Alta | Inteligência e Agendamento |
| **6. SaaS/Admin** | Média | Faturamento e Gestão |

---

### Inovação Recomendada: "IA Copywriter"
Após concluir a Etapa 5, você deve implementar a **Etapa Extra: IA**. Em vez de usar sempre o mesmo texto, o sistema enviará a descrição do produto para uma IA (como GPT-4o-mini) e ela gerará uma legenda diferente para cada grupo. Isso reduz drasticamente as chances de banimento no WhatsApp, pois as mensagens nunca são idênticas.

**Próximo Passo Sugerido:** Começar pela **Etapa 1** definindo a linguagem de programação. Você prefere que eu sugira as tecnologias exatas (ex: Node.js com React) ou você já tem uma preferência de linguagem?
