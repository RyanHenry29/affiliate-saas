# Guia Técnico de Implementação: Evoluindo o Esqueleto para o SaaS Final

Este guia é um complemento direto ao esqueleto que você enviou. Ele detalha como implementar as funcionalidades críticas dentro da estrutura de **Monolito Modular (NestJS)** e **Workers (BullMQ)** que já está desenhada no seu projeto.

---

## 1. Implementação do Multi-Tenancy e Admin Master
O seu `schema.prisma` já possui o campo `isAdminMaster` no `Tenant`.
*   **Ação:** Crie um `Guard` global no NestJS que verifica se o `Tenant` do usuário logado tem `isAdminMaster: true`.
*   **Bypass de Billing:** Se o tenant for Admin Master, o sistema deve ignorar as verificações de assinatura (`SubscriptionStatus.ACTIVE`) e permitir disparos ilimitados.
*   **Dica:** No `OfferService`, adicione um filtro que permita ao Admin Master visualizar e gerenciar ofertas de todos os marketplaces simultaneamente.

## 2. Motor de Mineração (Módulo `offers` e `marketplaces`)
A tabela `Offer` possui um `dedupeHash`. Isso é vital para evitar spam.
*   **Lógica de Scraping:** O `worker` deve rodar jobs periódicos para cada marketplace.
*   **Filtro de Qualidade:** Antes de salvar na tabela `Offer`, o serviço deve validar:
    *   `priceCents`: Se o preço for maior que o histórico médio, descarte.
    *   `title`: Use Regex para identificar nichos (ex: "panela" -> Dona de Casa).
*   **Segmentação:** Adicione uma coluna `nicheTag` na tabela `Offer` para que o `DispatchJob` saiba para quais grupos enviar.

## 3. Integração com Evolution API (Módulo `messaging`)
Você definiu uma interface `MessagingProvider`. Isso é excelente para trocar entre WhatsApp e Telegram.
*   **Evolution API:** Crie uma classe `EvolutionProvider` que implemente essa interface. Ela deve gerenciar o envio de `MediaMessage` (imagem + legenda).
*   **Anti-Ban:** No `DispatchJob`, não envie mensagens em massa. Use o BullMQ com um `delay` variável entre 30 a 90 segundos entre cada mensagem para simular comportamento humano.

## 4. Sistema de Billing e SaaS (Módulo `billing`)
*   **Webhooks:** Configure um endpoint `/billing/webhook` para receber confirmações do Stripe ou Mercado Pago.
*   **Sincronização:** Sempre que um pagamento for confirmado, atualize o `SubscriptionStatus` para `ACTIVE` e defina o `currentPeriodEnd`.
*   **Bloqueio Automático:** Crie um Job que roda toda meia-noite buscando Tenants com `currentPeriodEnd < now()`. Se encontrar, mude o status para `PAST_DUE` e o sistema de disparo deve parar automaticamente para esse usuário.

## 5. Próximos Passos de Codificação (Ordem de Prioridade)

| Prioridade | Módulo | Objetivo |
| :--- | :--- | :--- |
| **1** | `auth` | Garantir que cada usuário só veja seus próprios dados (Tenant Isolation). |
| **2** | `marketplaces/shopee` | Implementar o primeiro minerador funcional usando a API oficial. |
| **3** | `messaging/evolution` | Conectar um número de teste e disparar a primeira oferta com imagem. |
| **4** | `billing` | Implementar o fluxo de assinatura para permitir usuários externos. |
| **5** | `admin-panel` | Criar a tela onde você gerencia os limites de todos os usuários. |

---

## 6. Dicas de Ouro para o "Mãos Livres"
*   **Logs Estruturados:** Use o `Pino` ou `Winston` para logar cada tentativa de envio. Se o WhatsApp de um cliente desconectar, o log deve disparar um evento para o banco de dados e o frontend deve mostrar um aviso "⚠️ Instância Desconectada".
*   **Retry Logic:** No BullMQ, configure `attempts: 3` com `backoff: exponential`. Se o servidor do marketplace oscilar, o sistema tenta novamente em 5, 10 e 20 minutos antes de marcar como falha.

---
Este guia transforma o código que você já tem em um produto pronto para o mercado. O próximo passo é começar a preencher os arquivos dentro de `apps/api/src/modules/` seguindo estas orientações.
